<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>JOLPEC | HOME</title>
    <meta content="Jolpec Environmemtal Cleaning Services,Jolpec, Jolpec,cleaning, home cleaning , hospital cleaning , office cleaning,sweeping,dusting" name="keywords">
    <meta name="description" content="Jolpec Limited provides cleaning services to Commercial, Industrial, Residential, and Retail Properties in Lagos, Abuja, Porth Harcourt, and we continue to expand our services to various parts of the country">
    <meta name="author" content="Jolpec">
    <link rel="shortcut icon" href="images/favicon.png">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no,maximum-scale=0.7">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&amp;family=Roboto:wght@400;700&amp;display=swap"
          rel="stylesheet">
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
    <!--<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>-->
    <!--<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAtR_iVWb3_QuvDgBu0QohcVO9dl_Kugyk&callback=myMap"></script>-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAtR_iVWb3_QuvDgBu0QohcVO9dl_Kugyk&callback=initMap&libraries=&v=weekly" defer></script>

</head>
<body>

<?php require('utilities/nav-top.php');?>
<main id="tt-pageContent">
    <div class="container-indent no-margin mainSlider-wrapper" >
        <div class="loading-content">
            <div class="loading-dots"><img src="images/bolt.gif" alt=""></div>
        </div>
        <div id="js-mainSlider" class="mainSlider" >
            <div class="slide" >
                <div class="img--holder" data-bgslide="images/main-slider-new1.png"></div>
                <div class="slide-content">
                    <div class="container text-center js-rotation" data-animation="fadeInUpSm"
                         data-animation-delay="0s">
                        <div align="center" class="arrow" style="position: relative">
                            <img style="height: 100px; margin-top: -150px" src="images/arrow4.gif">
                        </div>
                        <div class="tt-title-01">Keeping You Wired</div>
                        <div class="tt-title-02">Facility management<br> service!</div>
                    </div>
                </div>
            </div>
            <div class="slide">
                <div class="img--holder" data-bgslide="images/mainslide-03.jpg"></div>
                <div class="slide-content">
                    <div class="container text-center js-rotation" data-animation="fadeInUpSm"
                         data-animation-delay="0s">
                        <div onclick="scroll()" align="center" class="arrow" style="position: relative">
                            <img style="height: 100px; margin-top: -150px" src="images/arrow4.gif">
                        </div>
                        <div class="tt-title-01">Making Our Clients Happier</div>
                        <div class="tt-title-02">Fire Fighting <br>and equipment sales</div>
                    </div>
                </div>
            </div>
            <div class="slide">
                <div class="img--holder" data-bgslide="images/mainslide-01.jpg"></div>
                <div class="slide-content">
                    <div class="container text-center js-rotation" data-animation="fadeInUpSm"
                         data-animation-delay="0s">
                        <div align="center" class="arrow" style="position: relative">
                            <img style="height: 100px; margin-top: -150px" src="images/arrow4.gif">
                        </div>
                        <div class="tt-title-01">We Can Light Everything</div>
                        <div class="tt-title-02">We also offer<br> janitorial services</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container order-form-wrapper container-lg-fluid container-lg__no-gutters" id="myDiv">
        <div class="order-form">
            <div class="order-form__title" id="js-toggle-orderform"><i class="tt-arrow down"></i> Request Service Today
            </div>
            <div class="order-form__content form-order">
                <form id="orderform" method="post" novalidate="novalidate" action="#">
                    <div class="form-group">
                        <input type="text" name="name" class="form-control" placeholder="Your name">
                    </div>
                    <div class="form-group">
                        <input type="text" name="email" class="form-control" placeholder="Your e-mail">
                    </div>
                    <div class="form-group">
                        <input type="text" name="phonenumber" class="form-control" placeholder="Your phone">
                    </div>
                    <div class="form-group">
                        <select name="typeofholiday" class="form-control">
                            <option selected value="Select Service" disabled>Select Service</option>                            <option value="Service 02">Service 02</option>
                            <option value="Service 03">Service 03</option>
                            <option value="Service 04">Service 04</option>
                            <option value="Service 05">Service 05</option>
                        </select>
                        <div class="form-group__icon icon-calendar"></div>
                    </div>
                    <div class="form-group">
                        <textarea rows="1" type="text" name="phonenumber" class="form-control" placeholder="Text"></textarea>
                    </div>
                    <div class="form-group">
                        <button class="tt-btn btn__color01" type="submit"><span class="icon-lightning"></span>
                            Request a Quote
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>





    <div class="section-indent">
        <div class="container container-md-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__02">AREAS OF SERVICE</div>
            </div>
            <div id="filter-layout" class="row justify-content-center gallery-innerlayout-wrapper js-wrapper-gallery">
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Electrical-Engineering.png" style="width: 100px;" alt="">
                        <p> Electrical Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Structural-Engineering.png" style="width: 100px;" alt="">
                        <p> Civil/Structural Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Manufacturing-Process-Design-Icon5.png" style="width: 100px;" alt="">
                        <p> Engineering Designs </p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Construction-Administration.png" style="width: 100px;" alt="">
                        <p> Engineering Consultancy</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Software-HECI.png" style="width: 100px;" alt="">
                        <p> Architectural Services</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/plumber.png" style="width: 100px;" alt="">
                        <p> Plumbing Services</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Structural-Engineering.png" style="width: 100px;" alt="">
                        <p> Structural Steel Fabrication</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys" >
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/roof.png" style="width: 100px;" alt="">
                        <p> Cladding (Aluco Bond)</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/curtin.png" style="width: 100px;" alt="">
                        <p> Curtain Walling</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/glassWall.png" style="width: 100px;" alt="">
                        <p> Glass Wall</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" ddsrc="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/doors.png" style="width: 100px;" alt="">
                        <p> Aluminum Doors</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/window.png" style="width: 100px;" alt="">
                        <p> Aluminum Windows</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Mechanical-Engineering2.png" style="width: 100px;" alt="">
                        <p> Mechanical Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/solar.png" style="width: 100px;" alt="">
                        <p> Solar Panels Installation and Maintenance</p>
                    </a>

                </div>

                <div style="display:none !important;" class="col-12 text-center tt-top-more">
                    <a href="#" class="tt-link tt-link__lg">
                        View all services
                        <span class="icon-arrowhead-pointing-to-the-right-1"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="section-indent">
        <div class="section__wrapper">
            <div class="container container-md-fluid">
                <div class="tt-info-value row">
                    <div class="tt-col-title col-md-4">
                        <div class="tt-title"><img class="bg-marker lazyload"
                                                   src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                                                   data-src="images/bg_marker.png" alt="">
                            <div class="tt-title__01">Our Statistics</div>
                            <div class="tt-title__02">Some Important Facts</div>
                        </div>
                    </div>
                    <div class="col-auto ml-auto">
                        <div class="tt-item">
                            <div class="tt-value">800+</div>
                            Electrification Projects
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="tt-item">
                            <div class="tt-value">480+</div>
                            Cleaning Services
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="tt-item">
                            <div class="tt-value">1000+</div>
                            Construction Projects
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>







    <div class="section-indent">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__img-more">
                <div class="layout01__img">
                    <div class="tt-img-main"><img
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAqAAAAIoAQMAAACMEcszAAAAA1BMVEUAAACnej3aAAAAAXRSTlMAQObYZgAAAERJREFUeNrtwQENAAAAwiD7p7bHBwwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIC0A7dIAAFubGEWAAAAAElFTkSuQmCC"
                            data-src="images/layout01-img01.jpg" class="lazyload" alt=""></div>
                    <div class="tt-img-more left-bottom"><img
                            src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                            data-src="images/layout01-img02.jpg" class="lazyload" alt=""></div>
                </div>
                <div class="layout01__content">
                    <div class="layout01__content-wrapper">
                        <div class="section-title text-left">
                            <div class="section-title__01">About Us</div>
                            <div class="section-title__02">Read about our company</div>

                        </div>
                        <p class="about-overview">
                            El-Jude Environmental Cleaning Services (EJECS) Limited is a registered company operating in different parts of the country with its head Office located in Lagos. We have a team of professionals. Our staff is timely, efficient, careful, detailed and friendly.
                        </p>
                        <p>
                            Since the inception of the company, our goal is to make sure that our client’s interest is the utmost priority. We also work towards providing our staff a company they are proud of and love to work with at any time.<br> This we do by continuous training of the staff to enable them grow and also discharge their duties very well.
                        </p>




                    </div>

                </div>
            </div>
            <p>
                Ejecs Limited provides Cleaning Services to Commercial, Industrial, Residential, Educational, Housing Estates, and Retail Properties in Lagos, Abuja, Port Harcourt, and Enugu, and we continue to expand our services to various parts of the country. With our experience in the cleaning industry, we specialize in providing our clients with a quality service at an affordable price.
            </p>
            <p>In addition to Cleaning Services, we also offer the following Services:</p>

            <ul class="tt-list01 tt-list-top">
                <li>Facility Management Services</li>
                <li>Gardening and Landscaping Services</li>
                <li>Personal Protective Equipment (PPE) Sales</li>
                <li>Fumigation and Pest Control</li>
            </ul>
            <p>At Ejecs we believe in treating everyone with respect, and more importantly take our role and responsibility very serious. Our company is built on the foundation of equal opportunity for every employee. We welcome good ideas that will contribute to the progress of our company from any of our staff.</p>
        <p>We would be glad to sit down with you to discuss the cleaning services you may require. To Request for a Free Cleaning Quote <a href="#">click here</a></p>
        </div>
    </div>




    <div class="section-indent">
        <div class="tt-slideinfo-wrapper slick-type01">
            <div class="tt-slideinfo">
                <div class="tt-item__bg">
                    <div data-bg="images/slideinfo-01.jpg" class="lazyload tt-item__bg-img"></div>
                    <div class="tt-item__bg-top"></div>
                </div>
                <div class="tt-item__content ">
                    <div class="tt-item__title"><span class="tt-icon"><img
                                    src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                                    class="lazyload" data-src="images/slideinfo-marker.png" alt=""></span><span class="tt-text">Civil<br> Engineering</span>
                    </div>
                    <div class="tt-item__description">We offer the highest level of responsiveness and reliability,
                        including on-line job management and reporting. Our highly experienced contractors across the
                        nation ensure that your premises are always maintained and compliant.
                    </div>
                    <div class="tt-item__btn"><a href="#">+</a></div>
                </div>
            </div>
            <div class="tt-slideinfo">
                <div class="tt-item__bg">
                    <div data-bg="images/slideinfo-02.jpg" class="lazyload tt-item__bg-img "></div>
                    <div class="tt-item__bg-top"></div>
                </div>
                <div class="tt-item__content">
                    <div class="tt-item__title"><span class="tt-icon"><img
                                    src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                                    class="lazyload" data-src="images/slideinfo-marker.png" alt=""></span><span class="tt-text">Electrical<br> Engineering</span>
                    </div>
                    <div class="tt-item__description">We offer the highest level of responsiveness and reliability,
                        including on-line job management and reporting. Our highly experienced contractors across the
                        nation ensure that your premises are always maintained and compliant.
                    </div>
                    <div class="tt-item__btn"><a href="#">+</a></div>
                </div>
            </div>
            <div class="tt-slideinfo">
                <div class="tt-item__bg">
                    <div data-bg="images/slideinfo-03.jpg" class="lazyload tt-item__bg-img"></div>
                    <div class="tt-item__bg-top"></div>
                </div>
                <div class="tt-item__content">
                    <div class="tt-item__title"><span class="tt-icon"><img
                                    src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                                    class="lazyload" data-src="images/slideinfo-marker.png" alt=""></span><span class="tt-text">Mechanical<br> Engineering</span>
                    </div>
                    <div class="tt-item__description">We offer the highest level of responsiveness and reliability,
                        including on-line job management and reporting. Our highly experienced contractors across the
                        nation ensure that your premises are always maintained and compliant.
                    </div>
                    <div class="tt-item__btn"><a href="#">+</a></div>
                </div>
            </div>
        </div>
    </div>







    <div class="section-indent">
        <div class="section__wrapper">
            <div class="container container-md-fluid">
                <div class="tt-info-value row">

                    <div class="col-auto">
                        <div class="tt-item">
                            <div class="tt-value" style="font-family: Harrington">JOLPEC LIMITED</div>
                            Testimonies from our clients
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="tt-box03 tt-box03__extraindent">
        <div class="container container-md-fluid">
            <div class="row no-gutters">
                <div class="col-md-7">
                    <div class="tt-box03__content">
                        <div class="slick-type01 slick-dots-left" data-slick='{
								"slidesToShow": 1,
								"slidesToScroll": 1,
								"autoplaySpeed": 4500
							}'>
                            <div class="item">
                                <div class="item__row">
                                    <div class="tt-item__img"><img class="lazyload"
                                                                   src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                                                                   data-src="images/box03_img02.jpg" alt=""></div>
                                    <div class="tt-item__title">
                                        <div class="section-title text-left">
                                            <div class="section-title__01">What Our Clients Say</div>
                                            <div class="section-title__02">Fast and Reliable </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tt-item__content">
                                    <blockquote>
                                        Your immediate, personal responses to our requests are greatly appreciated!
                                        <cite>- Mr Albert.</cite>
                                    </blockquote>
                                </div>
                            </div>
                            <div class="item">
                                <div class="item__row">
                                    <div class="tt-item__img"><img class="lazyload"
                                                                   src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                                                                   data-src="images/box03_img02.jpg" alt=""></div>
                                    <div class="tt-item__title">
                                        <div class="section-title text-left">
                                            <div class="section-title__01">What Our Clients Say</div>
                                            <div class="section-title__02">Quality assurance & Cost Effective</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tt-item__content">
                                    <blockquote>
                                        We haven't enjoyed our living room like this in years. It seems so much more comfortable now!
                                        <cite>- Mr. Paul.</cite>
                                    </blockquote>
                                </div>
                            </div>
                            <div class="item">
                                <div class="item__row">
                                    <div class="tt-item__img"><img class="lazyload"
                                                                   src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                                                                   data-src="images/box03_img02.jpg" alt=""></div>
                                    <div class="tt-item__title">
                                        <div class="section-title text-left">
                                            <div class="section-title__01">What Our Clients Say</div>
                                            <div class="section-title__02">Professional Cleaning Service</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tt-item__content">
                                    <blockquote>
                                        I have and will continue to recommend you to anyone who asks about a good cleaning service. You're the best!
                                        <cite>- Mark.</cite>
                                    </blockquote>
                                </div>
                            </div>
                            <div class="item">
                                <div class="item__row">
                                    <div class="tt-item__img"><img class="lazyload"
                                                                   src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs="
                                                                   data-src="images/box03_img02.jpg" alt=""></div>
                                    <div class="tt-item__title">
                                        <div class="section-title text-left">
                                            <div class="section-title__01">What Our Clients Say</div>
                                            <div class="section-title__02">Reliable & Cost Effective</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tt-item__content">
                                    <blockquote>
                                        I was amazed at how little your service cost. I appreciate your honesty and integrity!
                                        <cite>- Mrs. Eunice.</cite>
                                    </blockquote>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tt-box03__img tt-visible-mobile lazyload" data-bg="images/box03_img01.jpg"></div>
                    <div class="tt-box03__extra">
                        <div class="tt-title">Emergency Service</div>
                        <p>If this is an emergency outside of normal business hours, call us</p>
                        <address><a href="tel:1(800)7654321"><i class="icon-telephone"></i> +234 816 842 3411</a>
                        </address>
                    </div>
                </div>
                <div class="tt-box03__img tt-visible-desktop lazyload" data-bg="images/box03_img01.jpg"></div>
            </div>
        </div>
    </div>
    <div class="section-indent">
        <div class="container">
      <div>
          <main id="tt-pageContent">
              <div class="section-indent-extra">
                  <div class="container container-lg-fluid"></div>
              </div>
              <div class="section-indent">
                  <div class="container container-md-fluid">
                      <div class="section-title max-width-01">
                          <div class="section-title__02">Rate Our Service </div>
                          <div class="section-title__01">Tell Us How Well We Have Been Serving You</div>
                      </div>
                      <div class="row justify-content-center">
                          <div class="col-md-8">
                              <form id="feedbackform" class="form-default" method="post" novalidate="novalidate" action="#">
                                  <div class="form-group"><input type="text" name="name" class="form-control"
                                                                 placeholder="Your Name * (First Name & Last Name)"></div>
                                  <div class="row">
                                      <div class="col-md-6">
                                          <div class="form-group"><input type="number" name="phonenumber" class="form-control"
                                                                         placeholder="Your telephone number"></div>
                                      </div>
                                      <div class="col-md-6">
                                          <div class="form-group"><input type="text" name="email" class="form-control"
                                                                         placeholder="Your e-mail address *"></div>
                                      </div>
                                  </div>

                                      <div class="form-group">
                                          <select id="rate_us_rate_us" name="rate_us"  class="input_quote form-control form-control-lg form-control-a">
                                              <option value=""> How do you feel about our services </option>
                                              <option value="good"> Good </option>
                                              <option value="impressed"> Impressed </option>
                                              <option value="very impressed" >very Impressed </option>
                                              <option value="bad">Bad</option>
                                              <option value="sad">Sad</option>
                                              <option value="very bad"> Very Bad</option>
                                              <option value="very sad"> Very Sad</option>
                                          </select >
                                      </div>

                                  <div class="form-group"><textarea name="message" class="form-control" rows="4"
                                                                    placeholder="Message *"></textarea></div>
                                  <div class="form-group text-center">
                                      <button class="tt-btn btn__color01" type="submit">
                                          <span class="fa fa-thumbs-o-up"></span>
                                          RATE US NOW!
                                      </button>
                                  </div>
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </main>
      </div>


        </div>
    </div>


    <div class="section-indent">
        <div class="tt-box01 lazyload" data-bg="images/box01-bg02-desktop.jpg">
            <div class="container">
                <div class="tt-box01__holder">
                    <div class="tt-box01__video">
                        <a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="tt-video js-video-popup">
                            <i class="icon-arrowhead-pointing-to-the-right-1"></i>
                        </a>

                    </div>
                    <div class="tt-box01__description"><h4 class="tt-box01__title">We Are  <span class="tt-base-color">Best </span>in
                            What We Do</h4>
                        <p>Our experienced electricians are highly trained in all aspects of electrical service, from
                            office lighting and security systems to emergency repair.</p>
                        <div class="tt-row-btn"><a class="tt-btn btn__color01" data-toggle="modal"
                                                   data-target="#modalMakeAppointment" href="#"><span
                                        class="icon-lightning"></span>Book Appointment</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section-indent">
        <div class="container container-md-fluid">
            <div class="row">
                <div class="col-sm-6 col-lg-4">
                    <div class="section-title text-left section-title_indent-01">
                        <div class="section-title__01"><i class="fa fa-envelope-square"></i> Email</div>
                        <h4 class="section-title__02" >info@ejecs.com.ng</h4>
                        <img class="bg-marker01 lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/bg_marker02.png" alt=""></div>
                    <div class="tt-news-list">
                        <div class="tt-item">
                            <h4 class="tt-item__title">
                                <i class="icon-map-marker"></i>
                                <a href="blog-item.html">
                                    Address:
                                </a>
                            </h4>
                            <div class="col-lg-12">
                                <p class="col-md-6">No 8 Agunbiade Street, Greenland Estate, Isheri, Lagos</p>
                            </div>
                        </div>
                        <div class="tt-item">
                            <h4 class="tt-item__title">
                                <i class="icon-telephone"></i>
                                <a href="blog-item.html">Phone Numbers:</a>
                            </h4>
                            <p class="">+234 816 842 3411</p>
                            <p class="margin-top-phone">+234 806 693 4496</p>
                            <p class="margin-top-phone">+234 803 342 5589</p>
                            <b class="margin-top-phone"><i class="fa fa-whatsapp"></i> +234 803 342 5589</b>
                        </div>
                    </div>
                </div>
                <div class="divider d-block d-sm-none"></div>
                <div class="col-sm-6 col-lg-8">
                    <main id="tt-pageContent">
                        <div class="section-indent-extra">
                            <div class="container container-lg-fluid"></div>
                        </div>
                        <div class="section-indent">
                            <div class="container container-md-fluid">
                                <div class="section-title max-width-01">
                                    <div class="section-title__01">Contact Us</div>
                                    <div class="section-title__02">Get In Touch with Us </div>
                                    <div class="section-title__03">Want to learn more? Fill out the form to hear from an Ejecs cleaning expert.</div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-md-8">
                                        <form id="feedbackform" class="form-default" method="post" novalidate="novalidate" action="#">
                                            <div class="form-group"><input type="text" name="name" class="form-control"
                                                                           placeholder="Your Name * (First Name & Last Name)"></div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group"><input type="number" name="phonenumber" class="form-control"
                                                                                   placeholder="Your telephone number"></div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group"><input type="text" name="email" class="form-control"
                                                                                   placeholder="Your e-mail address *"></div>
                                                </div>
                                            </div>
                                            <div class="form-group"><textarea name="message" class="form-control" rows="4"
                                                                              placeholder="Message *"></textarea></div>
                                            <div class="form-group text-center">
                                                <button class="tt-btn btn__color01" type="submit">
                                                    <span class="fa fa-send"></span>
                                                    Contact us
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
                </div>
            </div>
        </div>
    </div>

</main>
<?php include("utilities/footer.php");?>
<a href="#" id="js-backtotop" class="tt-back-to-top"><i class="icon-lightning"></i></a></body>
<script src="js/jquery-3.4.1.min.js"></script>
<script async="" src="js/bundle.js"></script>
<script>
    $(document).ready(function() {
        $('.arrow').click(function () {
            $('html, body').animate({
                scrollTop: $("#myDiv").offset().top
            }, 2000);
        });
    });




</script>
<script>
    //let map;

    function initMap() {
        map = new google.maps.Map(document.getElementById("maps"), {
            center: { lat: -34.397, lng: 150.644 },
            zoom: 8,
        });
    }

</script>


</html>