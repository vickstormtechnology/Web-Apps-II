<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>JOLPEC | ABOUT</title>
    <meta content="Jolpec Environmemtal Cleaning Services,Jolpec, Jolpec,cleaning, home cleaning , hospital cleaning , office cleaning,sweeping,dusting" name="keywords">
    <meta name="description" content="Jolpec Limited provides cleaning services to Commercial, Industrial, Residential, and Retail Properties in Lagos, Abuja, Porth Harcourt, and we continue to expand our services to various parts of the country">
    <meta name="author" content="Jolpec">
    <link rel="shortcut icon" href="images/favicon.png">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no,maximum-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/preloader.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.css" rel="stylesheet"/>
    <link rel="stylesheet" href="css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&amp;family=Roboto:wght@400;700&amp;display=swap"
          rel="stylesheet">
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <style>
        .owl-carousel {
            position: relative;
        }
        .owlNavNew{
            font-size: 20px;
            font-weight: bold;
            cursor: pointer;
        }
        .owl-prev2 {
            float: left;
            left:0;
        }
        .owl-next2 {
            right:0;
            float: right
        }

        @media screen and (max-width: 700px) {
            /*.owl-prev {
                margin-left: 30px;
                left:0;
            }
            .owl-next {
                right:0;
                margin-right: 30px;
            }
            .about2{
                margin-top: 5px !important;
            }*/
        }

    </style>
</head>
<body>
<div id="preloader">
    <div id="status"></div>
</div>
<?php require('utilities/nav-top.php');?>
<div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg.jpg')">
    <div class="container container-lg-fluid">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li>About Us</li>
        </ul>
    </div>
</div>
<main id="tt-pageContent">


<div class="owl-carousel" id="aboutTop">
    <div class="section-indent item" >
        <div class="container container-lg-fluid" >
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more" >
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main"><img src="images/layout01-img03.jpg" alt=""></div>
                    <div class="tt-img-more left-bottom"><img src="images/layout01-img03-02.jpg" alt=""></div>
                </div>
                <div class="layout01__content" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper" >
                        <div class="section-title text-left" >
                            <div class="section-title__01">About Our Company</div>
                        </div>
                        <p >
                            El-Jude Environmental Cleaning Services (EJECS) Limited is a registered company operating in
                            different parts of the country with its head Office located in Lagos. We have a team of professionals.
                            Our staff is timely, efficient, careful, detailed and friendly. Since the inception of the company,
                            our goal is to make sure that our client’s interest is the utmost priority. We also work towards
                            providing our staff a company they are proud of and love to work with at any time. This we do
                            by continuous training of the staff to enable them grow and also discharge their duties very well.
                            Ejecs Limited provides Cleaning Services to Commercial, Industrial, Residential, Educational,
                            Housing Estates, and Retail Properties in Lagos, Abuja, Port Harcourt, and Enugu, and we continue
                            to expand our services to various parts of the country. With our experience in the cleaning
                            industry, we specialize in providing our clients with a quality service at an affordable price.
<br>
                            In addition to Cleaning Services, we also offer the following Services:
                        </p>
                        <ul class="tt-list01 tt-list-top">
                            <li>Facility Management Services</li>
                            <li>Gardening and Landscaping Services</li>
                            <li>Personal Protective Equipment (PPE) Sales</li>
                            <li>Fumigation and Pest Control</li>
                        </ul>
                    </div>
                </div>
            </div>
            <p class="underText" >
                At Ejecs we believe in treating everyone with respect, and more importantly take our role and responsibility very serious. Our company is built on the foundation of equal opportunity for every employee. We welcome good ideas that will contribute to the progress of our company from any of our staff.

                We would be glad to sit down with you to discuss the cleaning services you may require.We would be glad to sit down with you to discuss the cleaning services you may require. To Request for a Free Cleaning Quote <a href='javascript:void();' style='color:purple;font-weight:700;font-style:italic;'data-toggle="modal" data-target="#modalMakeAppointment" >click here </a>
            </p><br>
                <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
                <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>




    <div class="section-indent item animated">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Our Vision
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            To Continually deliver the best Environmental Cleaning Services to our esteemed Clients using the advanced Technology available with adequate professionalism to exceed our client’s expectations.
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Our Mission
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            We are committed to delivering quality Janitorial and Environmental Cleaning Services at all times, and ensuring that our client’s organization policies are respected on the course of rendering our services.
                        </p>
                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Our Core Values
                        </h3>
                        <ul class="tt-list01 tt-list-top">
                            <li>Integrity</li>
                            <li>Professionalism</li>
                            <li>Innovation</li>
                            <li>Excellence</li>
                            <li>High level of productivity</li>
                            <li>Team work</li>
                            <li>Growth</li>
                        </ul>
                    </div>
                </div>
            </div>
            <br>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>



    <div class="section-indent item animated">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Our Commitment
                        </h3>
                        <p class="w2-text formatted_p" style="color: black;font-family: arial;font-size: 0.9rem;">
                            With a focus on environmental safety and sustainability, Ejecs Limited is dedicated to doing whatever it takes to care for any surface, of any size, at any time. Our staff practice professionalism in all they do, and they are committed to respecting your space and cleaning for good health.
                        </p>
                        <p class="w2-text formatted_p" style="color: black;font-family: arial;font-size: 0.9rem;">
                            At Ejecs professionalism is our watchword, we give you the best cleaning services at a very affordable price. With our expertise in Environmental Cleaning, we are ready to give your Homes, Offices, Industries, Housing Estates, Schools, Halls the Cleaner and healthier environment you anticipated using only environmentally safe cleaning products to protect our environment. We use environmentally friendly materials that all our employees have been trained to use.<br>

    At Ejecs we believe in treating everyone with respect, and more importantly take our role and responsibility very serious. Our company is built on the foundation of equal opportunity for every employee. Careful Selection, Training and Support are of upper most importance.<br>
                            We welcome good ideas that will contribute to the progress of our company from any of our staff.
                        </p>

                    </div>
                </div>

            </div>

            <h4 class="lead sub_title" style="color:#f47629;font-size:1.2rem;">
                Health and Safety Policy Statement
            </h4>
            <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
            <ol class="list_item_unset" style="color: black;">
                <li>Ejecs is committed to providing a healthy and safe working environment for
                    all employees and non-employees affected by our activities. We will do all that is
                    reasonably practicable to ensure a safe and healthy working environment.
                </li>
                <br>
                <li>We consider health and safety as an important part of all our management systems
                    and that clear communication and co-operation between management,
                    employees and the client are important in order to achieve a high standard of health and safety at work.
                </li>
                <br>
                <li>     Ejecs will:
                    <br>
                    •	 &nbsp&nbsp Initiate and maintain a safe and healthy workplace, to ensure that employees, customers, visitors and the environment are not exposed to risks arising from our cleaning activities.
                    <br>•	&nbsp&nbsp  Ensure that employees have adequate support, supervision, relevant health and safety documentation, information and training required in order to make them aware of potential hazards within the workplace.
                    <br>•	&nbsp&nbsp Make available all necessary Safety Devices and Personal Protective Equipment (PPE).
                    <br>•&nbsp&nbsp&nbsp	 Ensure records are maintained with regard to safe systems of work, risk assessments, employee training, work equipment inspections.
                    <br>•	&nbsp&nbsp Ensure that continual attention is paid to the provision of health & safety information, supervision and training for all employees.
                    <br>•	&nbsp&nbsp  Ensure that the Health and Safety Regulations as dictated by our customers are fully complied with.
                </li>
                <br>
                <li>
                    Ejecs believes in improving health and safety standards
                    through constant monitoring and reviewing of its health and
                    safety policies and procedures. A safe and healthy workplace can only be achieved
                    if employees accept responsibility for their own health and safety and that of other persons who may be affected
                    by their work activities.

                </li>
            </ol>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
            </p><br>
        </div>
    </div>



    <div class="section-indent item animated ">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h5 class="lead sub_title" style="color:#f47629;font-size:1.2rem;">
                            Employment Training Programmes
                        </h5>
                        <p class="w2-text formatted_p" style="color: black;font-family: arial;font-size: 0.9rem;">
                            <b class="sub_title2"> Safety Training - </b> At Ejecs, cleaning staff are trained in the relevant
                            aspects of cleaning duties required of them. All training is conducted in a manner respectful of our employees’
                            unique needs. All supervisors and managers,
                            apart from being well-versed in all aspects of the highest Cleaning Standards and Site specific procedures, are also trained in the Selection of Cleaning Material,
                            best suited for both the job and the environment in which it is to be used.

                            <br>
                            <br>Records of training are maintained on each employee for all training he or she receives while working at Ejecs Limited. The documentation describes the topics included in the training, provides a general outline of the training course, the name and qualifications of the trainer, and the date(s) and duration of the training. For current employees,
                            records are retained for two years from their hiring date; records are also retained for one year for former employees.
                            <br><br>

                        </p>

                        <h4 class="lead sub_title" style="color: #f47629">This Training comes in the following stages: </h4>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            <b class="sub_title2"> Induction Training - </b> A full Health and Safety talk explaining the potential hazards of cleaning equipment and materials and an explanation of how these hazards can be found within every day procedures.
                            In addition, we undertake a demonstration of personal protective clothing.
                            <br>
                            <br>
                        </p>

                    </div>
                </div>
            </div>
            <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
                Our cleaning equipment is colour coded and employees are trained accordingly. Basic electrical equipment (vacuum cleaners)
                is made familiar to cleaners with explanations of basic safety awareness and maintenance.
                All Cleaning Operatives are given comprehensive training on Colour Coding,
                Transference of body fluids, Hand Washing and Accident Reporting.


                <b class="sub_title2"> Ongoing Training  -  </b>This keeps employees up to date with any changes in Materials
                or Cleaning Techniques used. When relevant changes are  introduced,
                Managers and Site Supervisors are mandated to train  staff on these changes.
            </p>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>




    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Equal Opportunities Policy Statement
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            At Ejecs we believe in treating everyone equally and with respect.
                            Our company is built on the foundation of equal opportunity for every employee. We imbibe a culture free from discrimination, harassment and victimization.  As such, we value diversity among our staff,
                            customers, suppliers and community and we respect the individual contributions of all people.
                            <br>
                            We want a workforce that reflects the diverse community
                            at large and expect all employees and associates to treat each other with dignity and respect.
                            <br>
                            <br>
                            We do not tolerate unfair decisions or practices that excludes or discriminates against a
                            colleague on the grounds of Gender, Age, Ethnic Origin, Religion, etc.
                            <br>
                            <br>
                            Decisions related to recruitment, disciplinary action,
                            dismissal or promotion are taken based on work criteria
                            and individual performance.
                            <br>
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Environmental Policy Statement
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            El-Jude Environmental Cleaning Services Limited recognizes
                            the importance of environmental protection
                            and is committed to operating its business
                            responsibly and in compliance with all legal
                            requirements relating to the supply of quality
                            cleaning services to buildings.
                        </p>
                    </div>
                </div>
            </div>
            <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
                The Directors of Ejecs are committed to providing control of activities
                to avoid unnecessary or unacceptable risks to employees, customers, the general public and the environment. This we do  by careful planning and assessment
                of all aspects and by determining controls with monitoring capabilities to ensure effectiveness.
                <br>
                <br>
                Our Operational  standards  shall  comply  with regulatory control, i.e. environmental Protection  Act and relevant Approved Codes of Practice. Operational standards shall continue to be developed and improved by on- going assessment, controls and monitoring concerning emissions of toxic fumes into the atmosphere and the leaking of
                dangerous substances into watercourses that might adversely affect people or the environment.
                <br>
                <br>
                The  objectives  of  the  Policy is to create  safety  and  environmental  awareness among  employees  at  all  levels  by effective  consultation  and  provision  of  all relevant training, information and supervision to maintain a safe and healthy working environment
                by taking positive steps to conserve energy resources and minimize waste and pollution.

                <br>
                The Environmental Policy shall be subjected to constant monitoring and periodic review that may result in revisions or amendments.
            </p>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>




    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Safeguard Policy Statement
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            Ejecs Ltd has introduced a Safeguarding Policy to fulfil our commitment to safeguard
                            and promote the welfare of children and young/vulnerable adults in the workplace.
                            <br>
                            <br>
                            Employees at Ejecs may come into contact with children, young or vulnerable adults in the course of our work with Schools, Universities,
                            and Housing Estates while performing general cleaning, window cleaning and building cleaning services.

                            <br>
                            <br>
                            At Ejecs we know that a child, or young/vulnerable adult, may be exposed to abuse by adults. The purpose of this policy is to make sure that the actions of any adult in our organization while performing the work for which they are employed to do, are transparent and
                            should safeguard the children and young/vulnerable adults that they may come into contact with.
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Colour Coding
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            Cross contamination is a real danger in cleaning operations. The danger lies in bacteria and germs being
                            transferred through cleaning cloths and other materials between Washroom Areas, Kitchens and Offices
                        </p>
                    </div>
                </div>
            </div>
            <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
                Proactive measures need to be taken to prevent Cross Contamination which could lead to Health and Safety being compromised at workplace. In order to prevent Cross Contamination,
                Ejecs Limited implements a strict Colour Coding of Cleaning Equipment and Materials.
                <br/>
                <br/>
                We keep all Mops and Cloths on their relevant Coloured Hooks and Clips.
                This ensures that the cloths and mops do not contaminate each other adhering to our Health and Safety policy.
                <br>
                <br>
                <span style="color:#f47629;font-size:1.2rem;">Cloths, Mops and Buckets at different Locations are Colour Coded as follows:</span>
                <br/>
            <ul class="tt-list01 tt-list-top">
                <li>Offices, Receptions, Common Areas  - Blue</li>
                <li>Kitchens        -       Green</li>
                <li>Toilets and Bathrooms            -      Red </li>
                <li>Laboratories         -        White </li>
            </ul>
            <br>
            Managers, Supervisors and Cleaning Operatives are fully conversant with this policy and are trained to use materials accordingly.

            </p><div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>

        </div>
    </div>






    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Why Choose Ejecs
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            No doubt, we have the right working force,
                            the cleaning knowledge and the easily affordable prices to
                            offer. You could even make some savings on your cleaning
                            expenses, but still receive a cleaning service of highest
                            standards.
                            <br>

                            If you are in need of deep cleaning of your Offices,
                            apartments, facilities, etc, we are simply the best.
                            We know you want the affordable cleaning services,
                            while still having the confidence that you will
                            receive a cleaner who is thorough and professional,
                            with keen attention to detail.
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Why Ejecs is the Best Cleaning Service
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            <b>Instant online booking -</b>
                            Book online instantly, and schedule your first cleaning
                            for as early as the next day. Get your facility cleaned<br>

                            <b>Friendly, Vetted Professionals -</b>
                            All professionals on the Ejecs platform are screened,
                            background checked, and are rated by customers to ensure quality.<br>

                            <b>Screening/Background Check -</b>
                            Ejecs takes definite approach to screening that
                            applies to those cleaning and Ejecs service
                            professionals that may be booked and paid for directly
                            through the Ejecs platform.

                            Ejecs Screening Process has
                            created a multi-step process to screen potential cleaning
                            service professionals before they may be booked and paid
                            for directly through the Ejecs platform.
                        </p>
                    </div>
                </div>
            </div>
            <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
                The process is
                designed to filter qualified potential cleaning service
                professionals with appropriate backgrounds in compliance
                with applicable law.
                The potential cleaning service
                professional must provide detailed personal information.
                These service professionals must provide their full name,
                address, date of birth, Valid IDs, and a valid form of
                identification and also validate their cleaning services
                experience.
            </p>

            <p style="color: black;font-family: arial;font-size: 0.9rem;">
                <span style="color:#f47629;font-size:1.2rem;">Identity Check  </span><br>
                Valid IDs like National Identification Card, Driver’s
                License, Int’l Passport are used to verify these potential
                service professionals' identities.
                If an identity cannot be verified, Ejecs will not
                engage such a professional.
            </p>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>






    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Cleaned the Way You Want
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            Ejes strives to match you with the right professional.
                            We also provide you with a team of professionals to provide
                            backup in case of scheduling conflicts.
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Flexible Scheduling
                        </h3>
                        <p class="w2-text formatted_p" style="color: black;font-family: arial;font-size: 0.9rem;">
                            Ejecs helps you schedule your weekly, biweekly, or
                            monthly cleaning, so you can focus on the other things
                            important to you. Reschedule or adjust the frequency of
                            your cleanings as needed. Get the benefit of a regularly
                            cleaned facility.
                        </p>
                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            The Ejecs Happiness Guarantee
                        </h3>
                        <p style="color: black;font-family: arial;font-size: 0.9rem;">
                        Your happiness is our goal,
                        therefore, we try to match you with the right professional
                        every time. If you are not satisfied with the quality of
                        the service you booked and paid for directly on the
                        Ejecs platform, we’ll send another professional at
                        no extra charge for your next booking.
                        </p>
                    </div>
                </div>
            </div>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>





    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Green Cleaning
                        </h3>
                        <p class="w2-text formatted_p" style="color: black;font-family: arial;font-size: 0.9rem;">
                            As society works to become greener, Ejecs has committed itself to providing all of our clients with safe and environmentally responsible green cleaning services. Our green cleaning services use environmentally friendly products while working to reduce contaminants that pollute our surroundings.
                        </p>
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Clean and Green
                        </h3>
                        <p style="color: black;font-family: arial;font-size: 0.9rem;">
                            Traditionally, the concept of “green” has centered on
                        preventing pollution, minimizing waste and recycling,
                        all to prevent unwanted matter from harming the natural environment.
                        The concepts of ‘clean and “green’ are complimentary.
                        Clean is a condition free of unwanted matter. Unwanted matter
                        is any substance that obstructs human endeavors, poses a risk or
                        causes an undesirable or adverse effect. Often this type of matter is
                        referred to as pollution, although it goes by other names, such as wastes, dirt, dust, trash, etc
                            <br><br>
                            Cleaning is the method used to achieve a clean environment.
                            It can best be viewed as a fundamental environmental management
                            process of putting unwanted matter in its proper place.
                            This ensures an environment that is sustainable and functioning.
                            <br><br>
                        </p>
                    </div>
                </div>
            </div>
            <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
                A clean environment can be achieved by disinfection and sanitation.
                An environment is considered disinfected if the vast majority (99 percent)
                of its harmful substances are removed or made safe. The pathogens, most threatening to humans, also must be eliminated.
                <br>
                At a minimum, cleaning always must attain a state of “sanitation,”
                since unsanitary conditions pose a likely health risk. Cleaning is designed to rectify any
                risky conditions. Environments must be cleaned regularly to keep them sanitary. If the health risk has
                not improved to a sanitary level, cleaning has not been accomplished.
                <br><br>Ejecs employees are trained in Green Cleaning service best practices, and the use of environmentally preferable products. Our eco-friendly office cleaning practice include, educating our clients about the importance of Green Cleaning Services, and the use of Green Cleaning Products
            </p>

            <p style="color: black;font-family: arial;font-size: 0.9rem;">

            </p>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>





    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            What is Green Cleaning
                        </h3>
                        <p class="w2-text formatted_p" style="color: black;font-family: arial;font-size: 0.9rem;">
                            Green cleaning is a holistic approach to janitorial services that takes into account the health, safety, and environmental risks of products and processes associated with cleaning.
                            <br>
                            In other words, it is an approach to cleaning that involves the use of alternative products, applying those products in different ways. Green cleaning is a concept; it is a collection of new tools and practices that can be applied to traditional approaches. Green cleaning approaches vary from building to building.
                            <br>
                            Green cleaning could be achieved if the products and processes used are targeted to the specific risks associated with each building. The participation of the building managers, janitorial personnel, and building occupants is strongly encouraged in the development of a green cleaning plan.

                        </p>
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Why is Green Cleaning Important
                        </h3>
                        <p style="color: black;font-family: arial;font-size: 0.9rem;">
                            The aim of Green Cleaning is to reduce the risk associated with the use of cleaning chemicals. Risk is the measure of the probability and severity of harm to human health or the environment. It is based on the type and toxicity of a hazard, and the type and degree of exposure to that hazard. Risk is characterized by evaluating hazard and exposure,with the channels (eyes, skin, lungs,mouth, contaminated air, water,soil) through which people or the environment are likely to become exposed.
                        </p>
                    </div>
                </div>
            </div>
            <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
                Despite the changes that are made to traditional Products and Processes used in cleaning, cleaning of buildings like all other activities in life will never be achieved without risk. Current cleaning practices might pose very high risks or avoidable risks, and changing certain practices and products might reduce hazardous practices with alternatives that are also effective.
            </p>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>





    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Benefits of Green Cleaning
                        </h3>
                        <ul class="tt-list01 tt-list-top">
                            <li>
                                Reduce health effects to building occupants and janitorial staff.
                            </li>
                            <li>
                                Increase safety by reducing the likelihood and frequency of fires,explosions, spills, and splashes.
                            </li>
                            <li>
                                Reduce environmental impacts, and environmental issues such as air pollution, water pollution, ozone depletion, and climate change. Green cleaning also reduces the toxicity of products and chemicals requiring disposal.
                            </li>
                            <li>
                                Reduce costs to building maintenance,or the janitorial company associated with sick leave, and productivity loss.
                            </li>
                            <li>	Increase occupant and worker satisfaction.This can result from decreased health effects.</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>
</div>

    <!--<div align="center" class="col-lg-6 col-md-6 col-sm-6 arrow-box">
        <div id="prev-slide" class="prev" style='font-size: 30px;font-weight: bold;float: left'><i class='fa fa-chevron-left'></i>Prev</div>
        <div id="next-slide" class="next" style='font-size: 30px;font-weight: bold;float: right'>Next<i class='fa fa-chevron-right'></i></div>
    </div>-->

    <div class="section-indent">
        <div class="container container-md-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__02">AREAS OF SERVICE</div>
            </div>
            <div id="filter-layout" class="row justify-content-center gallery-innerlayout-wrapper js-wrapper-gallery">
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Electrical-Engineering.png" style="width: 100px;" alt="">
                        <p> Electrical Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Structural-Engineering.png" style="width: 100px;" alt="">
                        <p> Civil/Structural Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Manufacturing-Process-Design-Icon5.png" style="width: 100px;" alt="">
                        <p> Engineering Designs </p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Construction-Administration.png" style="width: 100px;" alt="">
                        <p> Engineering Consultancy</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Software-HECI.png" style="width: 100px;" alt="">
                        <p> Architectural Services</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/plumber.png" style="width: 100px;" alt="">
                        <p> Plumbing Services</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Structural-Engineering.png" style="width: 100px;" alt="">
                        <p> Structural Steel Fabrication</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys" >
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/roof.png" style="width: 100px;" alt="">
                        <p> Cladding (Aluco Bond)</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/curtin.png" style="width: 100px;" alt="">
                        <p> Curtain Walling</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/glassWall.png" style="width: 100px;" alt="">
                        <p> Glass Wall</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" ddsrc="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/doors.png" style="width: 100px;" alt="">
                        <p> Aluminum Doors</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/window.png" style="width: 100px;" alt="">
                        <p> Aluminum Windows</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Mechanical-Engineering2.png" style="width: 100px;" alt="">
                        <p> Mechanical Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/solar.png" style="width: 100px;" alt="">
                        <p> Solar Panels Installation and Maintenance</p>
                    </a>

                </div>

                <div style="display:none !important;" class="col-12 text-center tt-top-more">
                    <a href="#" class="tt-link tt-link__lg">
                        View all services
                        <span class="icon-arrowhead-pointing-to-the-right-1"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>



    <div class="section-indent">
        <div class="container container-lg-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__01">Our Advantages</div>
                <div class="section-title__02">Reasons You Should Call Us</div>
                <div class="section-title__03">Electrician is your single source for a complete range of high-quality
                    electrical services, including design/build, engineering and maintenance.
                </div>
            </div>
            <div class="row tt-services-promo__list justify-content-center">
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value tt-value__indent">1</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-hours"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">24/7 Emergency Services</div>
                                <p>24/7 emergency electrician you can trust.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value">2</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-tool2"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">Free Estimates</div>
                                <p>Yes, we offer free estimates for electrical additions or replacements.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value">3</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-price-tag"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">Low Price Guarantee</div>
                                <p>We strive to offer the lowest price on the market.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</main>
<?php include("utilities/footer.php");?>
<a href="#" id="js-backtotop" class="tt-back-to-top"><i class="icon-lightning"></i></a>



<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/preloader.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/owl-Custom.js"></script>
<script async="" src="js/bundle.js"></script>
</body>
</html>