<footer id="tt-footer">
    <div class="footer-wrapper">
        <div class="container container-lg-fluid container-lg__no-gutters">
            <form id="subscribeform" method="post" novalidate="novalidate" action="#">
                <div class="f-form">
                    <div class="f-form__label">
                        Tell People About Us

                    </div>
                    <div class="f-form__input" style="float: right;margin-left: 130px">
                        <button  class="tt-btn btn__color02" type="submit">
                            <span style="color: #f4fcff" class="fa fa-twitter"></span>
                            Tweet to @EjecsLimited</span>
                        </button>
                    </div>
                    <div class="f-form__btn">

                    </div>
                </div>
            </form>
        </div>
        <div class="container container-lg-fluid container-lg__no-gutters">
            <div class="f-holder row no-gutters">
                <div class="col-xl-7">
                    <div class="additional-strut">
                        <div class="row">
                            <div class="col-xl-6">
                                <div class="f-logo">
                                    <a href="index.php" class="f-logo">
                                        <img style="width: 80px;" src="images/logo.png" alt="">
                                        <span class="tt-text">EJECS</span>
                                    </a><!-- /logo -->
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="f-info-text">Our experienced electricians are highly trained in all aspects
                                    of electrical service, from office lighting and security systems to emergency
                                    repair.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-8 col-md-7">
                            <div class="col-sm-5 col-md-5" style="float: left; color: white;" align="left">
                                    <b style="color: #f47629;">SITE MAP</b>
                                    <ul class="footer-menu">
                                        <li><a href="#">Home</a></li>
                                        <li><a href="#">About Us</a></li>
                                        <li><a href="#">Contacts Us</a></li>
                                        <li><a href="#">Request a Quote</a></li>
                                        <li><a href="#">Rate Our Service</a></li>
                                    </ul>
                            </div>
                            <div class="col-sm-7 col-md-7" style="float: left;color: white;" align="left">
                               <b style="color: #f47629;">OUR SERVICE</b>
                                <ul class="footer-menu">
                                    <li><a href="#">Weekend Cleaning</a></li>
                                    <li><a href="#">Cleaning Services</a></li>
                                    <li><a href="#">Estate Cleaning Services</a></li>
                                    <li><a href="#">Gardening & Landscaping</a></li>
                                    <li><a href="#">HSE</a></li>
                                    <li><a href="#">Janitorial Services</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-4 col-md-5">
                            <ul class="f-info-icon">
                                <li><span class="icon-map-marker"></span> No 8 Agunbiade Street, Greenland Estate, Isheri, Lagos
                                </li>
                                <li><span class="icon-clock-circular-outline-1 ln-icon-"></span> Info@ejecs.com.ng</li>
                                <li>
                                    <a href="tel:+234816 842 3411">
                                        <span class="icon-telephone"></span>
                                        +234 816 842 3411, <br>+234 806 693 4496, <br>+234 803 342 5589
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div id="map" >
                <!--<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.592945262037!2d3.2579057137282126!3d6.572946524412636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103b91a8b7cf9a3b%3A0x4ba81fd17ac95021!2sEl-Jude%20Environmental%20Cleaning%20Services%20Limited!5e0!3m2!1sen!2sng!4v1576273206611!5m2!1sen!2sng" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>-->
            </div>
            <div class="f-copyright row no-gutters">
                <div class="col-sm-auto">&copy; © 2020 Jolpec Ltd All Rights Reserved.</div>
                <div class="col-sm-auto ml-sm-auto">
                    <ul class="f-social">
                        <li><a href="#" class="icon-facebook-logo-button"></a></li>
                        <li><a href="#" class="icon-twitter-logo-button"></a></li>
                        <li><a href="#" class="icon-instagram-logo"></a></li>
                        <li><a href="#" class="fa fa-whatsapp"></a></li>
                        <li><a href="#" class="fa fa-youtube"></a></li>
                        <li><a href="#" class="icon-google-plus-logo-button"></a></li>
                        <li><a href="#" class="icon-linkedin-logo-button"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>

<div class="modal fade" id="modalMakeAppointment" tabindex="-1" role="dialog" aria-label="myModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-body form-default modal-layout-dafault">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span
                            class="icon-860796"></span></button>
                <div class="modal-titleblock">
                    <div class="modal-title">Make an Appointment</div>
                </div>
                <form class="form-modal" id="jsFormMakeAppointment" method="post" novalidate="novalidate" action="#">
                    <div class="form-group"><input type="text" name="name" class="form-control" id="modalName01"
                                                   placeholder="Your Name *"></div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group"><input type="text" name="email" class="form-control"
                                                           id="modalEmail01" placeholder="Your e-mail address *"></div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group"><input type="text" name="phone" class="form-control"
                                                           id="modalPhone01" placeholder="Your phone number"></div>
                        </div>
                    </div>
                    <div class="form-group"><input type="text" name="modalAddress" class="form-control"
                                                   id="modalAddress" placeholder="Address *"></div>
                    <div class="form-group">
                        <div class="custom-select">
                            <select name="typeofholiday" class="tt-select">
                                <option selected value="Select Service">Select Service</option>
                                <option value="Service 02">Service 02</option>
                                <option value="Service 03">Service 03</option>
                                <option value="Service 04">Service 04</option>
                                <option value="Service 05">Service 05</option>
                            </select>
                        </div>
                    </div>
                    <!--<div class="form-group"><input name="date" placeholder="Date of visit" autocomplete="off"
                                                   data-timepicker="true" class="js_datepicker-1 form-control"
                                                   type="text">
                        <div class="form-group__icon icon-747993"></div>
                    </div>-->
                    <div class="form-group">
                        <textarea name="message" class="form-control" placeholder="Your comment"></textarea>
                    </div>
                    <button type="submit" class="tt-btn btn__color01">
                        <span class="icon-lightning"></span>
                        Request a Quote
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>