<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from websmirno.site/viktor/electron/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 21 Dec 2020 12:54:10 GMT -->
<head>
    <meta charset="utf-8">
    <title>JOLPEC | SERVICE</title>
    <meta content="Jolpec Environmemtal Cleaning Services,Jolpec, Jolpec,cleaning, home cleaning , hospital cleaning , office cleaning,sweeping,dusting" name="keywords">
    <meta name="description" content="Jolpec Limited provides cleaning services to Commercial, Industrial, Residential, and Retail Properties in Lagos, Abuja, Porth Harcourt, and we continue to expand our services to various parts of the country">
    <meta name="author" content="Jolpec">
    <link rel="shortcut icon" href="images/favicon.png">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no,maximum-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/preloader.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/owlCustom/owl.carousel-custom.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&amp;family=Roboto:wght@400;700&amp;display=swap"
          rel="stylesheet">
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <style>
        @media screen and (max-width: 700px) {
            .mobile_slide{
                display: block !important;
            }
            .computer_slide{
                display: none !important;
            }
        }

    </style>
</head>
<body>

<div id="preloader">
    <div id="status"></div>
</div>
<?php require('utilities/nav-top.php');?>
<nav class="panel-menu" id="mobile-menu">
    <ul></ul>
    <div class="mm-navbtn-names">
        <div class="mm-closebtn">Close</div>
        <div class="mm-backbtn">Back</div>
    </div>
</nav>

<div class="owl-carousel-Custom navSlide">
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">A nice text here if need be</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg2.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">Another wonderful text</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg3.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">Another wonderful text</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<main id="tt-pageContent">

    <div class="section-indent" id="menu">
        <div class="container container-md-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__02">What We Offer</div>
            </div>
            <div id="filter-nav" align="center">
                Click on a photo or the read more link to learn more about our service
            </div>
            <div id="filter-layout" class="row justify-content-center tt-obj-wrapper">
                <div class="col-sm-4 col-md-3 show filter-all filter-commercial">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img ">
                            <img src="images/obj-img01.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 14px;">
                                <a href="services.php">Electrical Engineering</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-commercial">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/REVIT-_-BIM-_-CAD.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Civil/Structural Engineering</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-commercial">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/Manufacturing-Process-Design.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Engineering Designs</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-industrial">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/Construction-Contract-Administration.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Engineering Consultancy</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-industrial">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/archi.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Architectural Services</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-industrial">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/plumbingjpg.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Plumbing Services</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-residentiar">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/Structural-Engineering.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Structural Steel Fabrication</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-residentiar">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/aluco.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Cladding (Aluco Bond)</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-residentiar">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/curtail.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Curtain Walling</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-residentiar">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/glass_wall.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Glass Wall</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-residentiar">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/allumiDoors.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Aluminum Doors</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-residentiar">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/allumiWindow.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Aluminum Windows</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3 show filter-all filter-residentiar">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/Mechanical-Engineering.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Mechanical Engineering</a>
                            </div>
                        </div>
                    </div>
                </div><div class="col-sm-4 col-md-3 show filter-all filter-residentiar">
                    <div class="tt-obj tt-product">
                        <div class="tt-obj__img tt-product__img"><img src="images/services/Energy-Management.jpg" alt=""></div>
                        <div class="tt-obj__wrapper">
                            <div class="tt-obj__title" style="font-size: 18px;">
                                <a href="services.php">Solar Panels Installation and Maintenance</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center tt-top-more02">
                <a href="#" data-toggle="modal" data-target="#modalMakeAppointment" class="tt-btn btn__color01">
                    <span class="icon-lightning"></span>
                    Request a Service
                </a>
            </div>
        </div>
    </div>

    <div class="section-indent" style="background: rgb(247, 247, 247); padding-top: 70px;padding-bottom: 70px;box-shadow: 0px 5px 10px rgb(247, 247, 247)">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__single-img">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img computer_slide ">
                    <div class="tt-img-main"><img style="border-radius: 10px" src="images/obj-img01.jpg" alt=""></div>
                </div>
<!--.layout01 .layout01__img-->
                <div class="layout01__content" >
                    <div class="layout01__content-wrapper">
                        <div class="section-title text-left">
                            <div class="section-title__02" style="color: rgb(28, 107, 176)">ELECTRICAL ENGINEERING</div>
                        </div>
                        <p>
                            The Electrical Engineers of HODGE Engineering provide complete electrical system designs for your site and buildings to meet or exceed all local regulations. Safety will always be the top priority, and is the basis of all systems to safeguard persons and property from hazards arising from the use of electricity. Our electrical team has a wide range of experience and can offer custom solutions to meet and exceed their client needs.
                        </p>
                        <b>The following are some areas of expertise and electrical engineering services available:</b>
                    </div>

                </div>
            </div>


            <div class="row tt-services-promo__list justify-content-center" style="margin-top: 1px">
                <div class="col-sm-6 col-lg-6 tt-item">
                    <div class="tt-services-promo">
                        <div class="et_pb_text_inner">
                            <ul>
                                <li>Medium Voltage Power Systems Design</li>
                                <li>Low Voltage Power Systems Design</li>
                                <li>Indoor / Outdoor Lighting Design</li>
                                <li>Power + Load Studies Fault Current Analysis</li>
                                <li>Power Factor Correction</li>
                                <li>Coordination Studies</li>
                                <li>Lightning Protection + Grounding</li>
                                <li>Fire Alarm / Life Safety System Design</li>
                                <li>Control Circuiting + Panel Design</li>
                                <li>Process Control + Instrumentation</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6 tt-item">
                    <div class="tt-services-promo">
                        <div class="et_pb_text_inner">
                            <ul>
                                <li>Programmable Logic Controller Applications</li>
                                <li>UPS / Generator Emergency Power Systems</li>
                                <li>NFPA 70E Arc Flash Compliance Reports</li>
                                <li>Electrical Drawings + Specifications</li>
                                <li>New Equipment Check-Out + Startup Support</li>
                                <li>Home Electrical Inspections</li>
                                <li>Pool Grounding Inspections</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center tt-top-more02">
            <a href="#menu" class="tt-btn btn__color01">
                BACK TO MENU <span style="padding-left: 10px" class="fa fa-arrow-up"></span>
            </a>
        </div>
    </div>



    <div class="section-indent" style=" margin-top: 70px;padding-bottom: 40px;">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__single-img">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img computer_slide ">
                    <div class="tt-img-main"><img style="border-radius: 10px" src="images/services/Mechanical-Engineering.jpg" alt=""></div>
                </div>
                <!--.layout01 .layout01__img-->
                <div class="layout01__content" >
                    <div class="layout01__content-wrapper" >
                        <div class="section-title text-left">
                            <div class="section-title__02" style="color: rgb(28, 107, 176)">MECHANICAL ENGINEERING</div>
                        </div>
                        <p>
                            The Electrical Engineers of HODGE Engineering provide complete electrical system designs for your site and buildings to meet or exceed all local regulations. Safety will always be the top priority, and is the basis of all systems to safeguard persons and property from hazards arising from the use of electricity. Our electrical team has a wide range of experience and can offer custom solutions to meet and exceed their client needs.
                        </p>
                        <b>The following are some areas of expertise and electrical engineering services available:</b>
                    </div>

                </div>
            </div>


            <div class="row tt-services-promo__list justify-content-center" style="margin-top: 1px">
                <div class="col-sm-6 col-lg-6 tt-item">
                    <div class="tt-services-promo">
                        <div class="et_pb_text_inner">
                            <ul>
                                <li>Medium Voltage Power Systems Design</li>
                                <li>Low Voltage Power Systems Design</li>
                                <li>Indoor / Outdoor Lighting Design</li>
                                <li>Power + Load Studies Fault Current Analysis</li>
                                <li>Power Factor Correction</li>
                                <li>Coordination Studies</li>
                                <li>Lightning Protection + Grounding</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6 tt-item">
                    <div class="tt-services-promo">
                        <div class="et_pb_text_inner">
                            <ul>
                                <li>Programmable Logic Controller Applications</li>
                                <li>UPS / Generator Emergency Power Systems</li>
                                <li>NFPA 70E Arc Flash Compliance Reports</li>
                                <li>Electrical Drawings + Specifications</li>
                                <li>New Equipment Check-Out + Startup Support</li>
                                <li>Home Electrical Inspections</li>
                                <li>Pool Grounding Inspections</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center tt-top-more02">
            <a href="#menu" class="tt-btn btn__color01">
                BACK TO MENU <span style="padding-left: 10px" class="fa fa-arrow-up"></span>
            </a>
        </div>
    </div>




    <div class="section-indent" style="background: rgb(247, 247, 247); padding-top: 70px;padding-bottom: 70px;margin-top: 10px;box-shadow: 0px 5px 10px rgb(247, 247, 247)">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__single-img">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img computer_slide ">
                    <div class="tt-img-main"><img style="border-radius: 10px" src="images/services/Structural-Engineering.jpg" alt=""></div>
                </div>
                <!--.layout01 .layout01__img-->
                <div class="layout01__content" >
                    <div class="layout01__content-wrapper">
                        <div class="section-title text-left">
                            <div class="section-title__02" style="color: rgb(28, 107, 176)">STRUCTURAL ENGINEERING</div>
                        </div>
                        <p>
                            The Electrical Engineers of HODGE Engineering provide complete electrical system designs for your site and buildings to meet or exceed all local regulations. Safety will always be the top priority, and is the basis of all systems to safeguard persons and property from hazards arising from the use of electricity. Our electrical team has a wide range of experience and can offer custom solutions to meet and exceed their client needs.
                        </p>
                        <b>The following are some areas of expertise and electrical engineering services available:</b>
                    </div>

                </div>
            </div>


            <div class="row tt-services-promo__list justify-content-center" style="margin-top: 1px">
                <div class="col-sm-6 col-lg-6 tt-item">
                    <div class="tt-services-promo">
                        <div class="et_pb_text_inner">
                            <ul>
                                <li>Medium Voltage Power Systems Design</li>
                                <li>Low Voltage Power Systems Design</li>
                                <li>Indoor / Outdoor Lighting Design</li>
                                <li>Power + Load Studies Fault Current Analysis</li>
                                <li>Power Factor Correction</li>
                                <li>Coordination Studies</li>
                                <li>Lightning Protection + Grounding</li>
                                <li>Fire Alarm / Life Safety System Design</li>
                                <li>Control Circuiting + Panel Design</li>
                                <li>Process Control + Instrumentation</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-6 tt-item">
                    <div class="tt-services-promo">
                        <div class="et_pb_text_inner">
                            <ul>
                                <li>Programmable Logic Controller Applications</li>
                                <li>UPS / Generator Emergency Power Systems</li>
                                <li>NFPA 70E Arc Flash Compliance Reports</li>
                                <li>Electrical Drawings + Specifications</li>
                                <li>New Equipment Check-Out + Startup Support</li>
                                <li>Home Electrical Inspections</li>
                                <li>Pool Grounding Inspections</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center tt-top-more02">
            <a href="#menu" class="tt-btn btn__color01">
                BACK TO MENU <span style="padding-left: 10px" class="fa fa-arrow-up"></span>
            </a>
        </div>
    </div>



    <div class="section-indent">
        <div class="container container-lg-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__01">Our Advantages</div><br>
                <div class="section-title__02">Reasons You Should Call Us</div>
                <div class="section-title__03">Electrician is your single source for a complete range of high-quality
                    electrical services, including design/build, engineering and maintenance.
                </div>
            </div>
            <div class="row tt-services-promo__list justify-content-center">
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value tt-value__indent">1</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-hours"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">24/7 Emergency Services</div>
                                <p>24/7 emergency electrician you can trust.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value">2</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-tool2"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">Free Estimates</div>
                                <p>Yes, we offer free estimates for electrical additions or replacements.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value">3</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-price-tag"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">Low Price Guarantee</div>
                                <p>We strive to offer the lowest price on the market.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>


<?php include("utilities/footer.php");?>


<a href="#" id="js-backtotop" class="tt-back-to-top"><i class="fa fa-arrow-up"></i></a></body>
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="css/owlCustom/owl.carouselcustom.min.js"></script>
<script src="js/preloader.js"></script>
<script async="" src="js/bundle.js"></script>
<script async="" src="js/js.js"></script>

<script>
    $(document).ready(function() {
        var owl2 = $('.owl-carousel');
        owl2.owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
            autoHeight: true,
            animateIn: 'fadeIn', // add this
            animateOut: 'fadeOut', // and this
            dots: false,
            smartSpeed: 50,
            responsive: {
                0: {
                    items: 1,
                    //nav:true,
                    loop: true,
                    touchDrag: true
                },
                600: {
                    items: 1,
                    //nav:true,
                    loop: true,
                    touchDrag: true
                },
                1000: {
                    items: 1,
                    //nav:true,
                    loop: true,
                    touchDrag: true
                }
            }

        });
    });


    ///ALL TOP SLIDERS///
    $(document).ready(function() {
        var owl2 = $('.owl-carousel-Custom');
        owl2.owlCarouselCustom({
            items: 1,
            loop: true,
            //margin: 0,
            lazyLoad: true,
            autoplay: true,
            mouseDrag: false,
            animateIn: 'fadeIn', // add this
            animateOut: 'fadeOut', // and this
            dots: false,
            smartSpeed: 10,
            responsive: {
                0: {
                    items: 1,
                    //nav:true,
                    loop: true,
                    touchDrag: true
                },
                600: {
                    items: 1,
                    //nav:true,
                    loop: true,
                    touchDrag: true
                },
                1000: {
                    items: 1,
                    //nav:true,
                    loop: true,
                    touchDrag: true
                }
            }

        });
    });
</script>
</html>