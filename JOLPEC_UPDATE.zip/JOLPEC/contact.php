<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>JOLPEC | CONTACT</title>
    <meta content="Jolpec Environmemtal Cleaning Services,Jolpec, Jolpec,cleaning, home cleaning , hospital cleaning , office cleaning,sweeping,dusting" name="keywords">
    <meta name="description" content="Jolpec Limited provides cleaning services to Commercial, Industrial, Residential, and Retail Properties in Lagos, Abuja, Porth Harcourt, and we continue to expand our services to various parts of the country">
    <meta name="author" content="Jolpec">
    <link rel="shortcut icon" href="images/favicon.png">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no,maximum-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owlCustom/owl.carousel-custom.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&family=Roboto:wght@400;700&display=swap"
          rel="stylesheet">
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
</head>
<body>
<?php require('utilities/nav-top.php');?>
<nav class="panel-menu" id="mobile-menu">
    <ul></ul>
    <div class="mm-navbtn-names">
        <div class="mm-closebtn">Close</div>
        <div class="mm-backbtn">Back</div>
    </div>
</nav>
<div class="owl-carousel-Custom navSlide">
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">A nice text here if need be</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg2.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">Another wonderful text</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg3.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">Another wonderful text</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<main id="tt-pageContent mobile_contact " style="margin-top: 0px;"><br><br>
    <div class="section-indent-extra top_contact" >
        <div class="container container-lg-fluid">
            <div class="section__wrapper02 tt-contact-wrapper">
                <div class="row justify-content-center">
                    <div class="col-sm-6 col-md-4">
                        <div class="tt-contact">
                            <div class="tt-icon"><i class="icon-map-marker"></i></div>
                            <div class="tt-content">
                                <div class="tt-title">Address:</div>
                                <address>No 8 Agunbiade Street, Greenland Estate, Isheri, Lagos</address>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="tt-contact">
                            <div class="tt-icon"><i class="icon-clock-circular-outline-1"></i></div>
                            <div class="tt-content">
                                <div class="tt-title">Work Hours:</div>
                                Mon-Fri 08:00 AM - 06:00 PM<br>Sat-Sun: Emergency only
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="tt-contact">
                            <div class="tt-icon"><i class="icon-telephone"></i></div>
                            <div class="tt-content">
                                <div class="tt-title">Phone Numbers:</div>
                                <address><a href="tel:1(800)7654321">+234 816 842 341</a></address>
                                <address><a href="tel:1(800)7654322">+234 806 693 4496</a></address>
                                <address><a href="tel:1(800)7654322">+234 803 342 5589 (Whatsapp)</a></address>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-indent">
        <div class="container container-md-fluid">
            <div class="section-title max-width-01">

                <div class="section-title__02">Get In Touch with Us</div>
                <div class="section-title__03">Are you stumped by a home wiring project or problem or Want to learn more? Fill out the form
                    with the details of your situation and we can come to your aid.
                </div>
                <div class="section-title__01" >Contact Form</div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <form id="feedbackform" class="form-default" method="post" novalidate="novalidate" action="#">
                        <div class="form-group"><input type="text" name="name" class="form-control"
                                                       placeholder="Your Name *"></div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group"><input type="text" name="email" class="form-control"
                                                               placeholder="Your e-mail address *"></div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"><input type="text" name="phonenumber" class="form-control"
                                                               placeholder="Your phone number"></div>
                            </div>
                        </div>
                        <div class="form-group"><textarea name="message" class="form-control" rows="4"
                                                          placeholder="Qustion In Detail *"></textarea></div>

                        <div class="form-group text-center">
                            <button class="tt-btn btn__color01" type="submit"><span class="icon-lightning"></span>Contact
                                us
                            </button>
                        </div>
                    </form>
                </div>
                <div class="map-contact" id="map-contact"></div>
            </div>
        </div>
    </div>
</main>

<?php include("utilities/footer.php");?>
<script src="js/jquery-3.4.1.min.js"></script>
<script async="" src="js/bundle.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="css/owlCustom/owl.carouselcustom.min.js"></script>
<script src="js/owl-Custom.js"></script>
<script async="" src="js/js.js"></script>
<a href="#" id="js-backtotop" class="tt-back-to-top"><i class="fa fa-arrow-up"></i></a></body>
</html>