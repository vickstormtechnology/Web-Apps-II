


//ABOUT US SLIDER
$(document).ready(function() {
    var owl = $('.owl-carousel');
    owl.owlCarousel({
        items: 1,
        loop: false,
        //margin: 0,
        lazyLoad: true,
        autoplay: false,
        autoHeight: true,
        //autoplayTimeout: 700,
        //autoplayHoverPause: true,
        mouseDrag: false,
        touchDrag: false,
        pullDrag: false,
        dots: false,
        //navigation : true, // Show next and prev buttons
        //nav : true,
        smartSpeed :700,
        //navText : ["<div class='owlNav'><i class='fa fa-arrow-circle-left'></i> Back</div>","<div class='owlNav'>Read more <i class='fa fa-arrow-circle-right'></i></div>"],


        responsive: {
            0: {
                items: 1,
                //nav:true,
                loop:false,
                touchDrag: false
            },
            600: {
                items: 1,
                //nav:true,
                loop:false,
                touchDrag: false
            },
            1000: {
                items: 1,
                //nav:true,
                loop:false,
                touchDrag: false,
            }
        }

    });




    /*var owl = $('.owl-carousel');
    owl.owlCarousel();*/
    // Go to the next item
    $('.customNextBtn').click(function() {
        owl.trigger('next.owl.carousel');
        $('html, body').animate({
            'scrollTop' : $("#aboutTop").position().top
        });
    });
    // Go to the previous item
    $('.customPrevBtn').click(function() {
        // With optional speed parameter
        // Parameters has to be in square bracket '[]'
        owl.trigger('prev.owl.carousel', [300]);
        $('html, body').animate({
            'scrollTop' : $("#aboutTop").position().top
        });
    })

})









///ALL TOP SLIDERS///
$(document).ready(function() {
    var owl2 = $('.owl-carousel-Custom');
    owl2.owlCarouselCustom({
        items: 1,
        loop: true,
        //margin: 0,
        lazyLoad: true,
        autoplay: true,
        mouseDrag: false,
        animateIn: 'fadeIn', // add this
        animateOut: 'fadeOut', // and this
        dots: false,
        smartSpeed: 10,
        responsive: {
            0: {
                items: 1,
                //nav:true,
                loop: true,
                touchDrag: true
            },
            600: {
                items: 1,
                //nav:true,
                loop: true,
                touchDrag: true
            },
            1000: {
                items: 1,
                //nav:true,
                loop: true,
                touchDrag: true
            }
        }

    });
});





