
$(".tt-obj__btn").click(function () {
    window.location.href="checkout.php";
});

//modal auto focus
$('.search-modal').on('shown.bs.modal', function () {
    $('input').focus();
});




//Jump to aboutTop
function data(clickItem, scrollNumber) {
    $(clickItem).click(function(){//our company
        var scrollObject = scrollNumber;
        localStorage.setItem('scrollItem', scrollObject);//save data
        window.location.href="about.php";
    });


    var retrievedObject = localStorage.getItem('scrollItem');
    $('.owl-carousel').trigger('to.owl.carousel', retrievedObject);
}

//Implementation
$(document).ready(function() {
    data('.about', 0);
    data('.our-company', 0);
    data('.vision', 2);
    data('.commitment', 6);
    data('.why-choose-us',7);
});