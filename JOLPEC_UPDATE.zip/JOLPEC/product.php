<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>JOLPEC | ABOUT</title>
    <meta content="Jolpec Environmemtal Cleaning Services,Jolpec, Jolpec,cleaning, home cleaning , hospital cleaning , office cleaning,sweeping,dusting" name="keywords">
    <meta name="description" content="Jolpec Limited provides cleaning services to Commercial, Industrial, Residential, and Retail Properties in Lagos, Abuja, Porth Harcourt, and we continue to expand our services to various parts of the country">
    <meta name="author" content="Jolpec">
    <link rel="shortcut icon" href="images/favicon.png">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no,maximum-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/preloader.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owlCustom/owl.carousel-custom.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.css" rel="stylesheet"/>
    <link rel="stylesheet" href="css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&amp;family=Roboto:wght@400;700&amp;display=swap"
          rel="stylesheet">
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
</head>
<body>
<div id="preloader">
    <div id="status"></div>
</div>
<?php require('utilities/nav-top.php');?>
<div class="owl-carousel-Custom navSlide">
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">A nice text here if need be</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg2.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">Another wonderful text</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg3.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">Another wonderful text</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<main id="tt-pageContent">
    <div class="section-indent">
        <div class="container container-lg-fluid">
            <div class="row">
                <div class="col-md-4 col-lg-3 col-xl-3 leftColumn tt-aside" id="aside-js">
                    <div class="tt-block-aside tt-block-aside__shadow"><h3 class="tt-aside-title">Search</h3>
                        <div class="tt-aside-content">
                            <form class="form-default">
                                <div class="tt-aside-search"><input type="text" placeholder="Product search"> <a
                                            href="#" class="tt-btn-icon icon-search"></a></div>
                            </form>
                        </div>
                    </div>
                    <div class="tt-block-aside tt-block-aside__shadow"><h3 class="tt-aside-title">Categories</h3>
                        <div class="tt-aside-content">
                            <nav class="nav-categories">
                                <ul>
                                    <li><a href="#">Generators</a></li>
                                    <li><a href="#">Electronics</a></li>
                                    <li><a href="#">Extension Cords</a></li>
                                    <li><a href="#">Batteries &amp; Chargers</a></li>
                                    <li><a href="#">Electrical Tape &amp; Tools</a></li>
                                    <li><a href="#">Dimmers &amp; Receptacles</a></li>
                                    <li><a href="#">Wall Plates</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                    <div class="tt-block-aside tt-block-aside__shadow"><h3 class="tt-aside-title">Best Price</h3>
                        <div class="tt-aside-content">
                            <div class="tt-slider-price">

                                <div class="slider-value-row">
                                    <div class="tt-title"> Cleaning:</div>
                                    $10 -
                                    <div id="slider-snap-value-lower" class="slider-value"></div>
                                    $15
                                    <div id="slider-snap-value-upper" class="slider-value"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tt-block-aside tt-block-aside__shadow"><h3 class="tt-aside-title">Popular</h3>
                        <div class="tt-aside-content">
                            <div class="tt-popular">
                                <div class="tt-item">
                                    <div class="tt-item__img"><img src="images/product/product-01.jpg" alt=""></div>
                                    <div class="tt-item__layout">
                                        <div class="tt-title"><a href="#">Woods WiOn 15 amps Receptacle and USB
                                                Charger</a></div>
                                        <div class="tt-value"><a href="#" class="tt-icon-btn"><i
                                                        class="icon-808584"></i></a>
                                            <div class="tt-price">$41.99</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tt-item">
                                    <div class="tt-item__img"><img src="images/product/product-08.jpg" alt=""></div>
                                    <div class="tt-item__layout">
                                        <div class="tt-title"><a href="#">Powerboss 3500 watts Gasoline Portable
                                                Generator</a></div>
                                        <div class="tt-value"><a href="#" class="tt-icon-btn"><i
                                                        class="icon-808584"></i></a>
                                            <div class="tt-price">$329.99</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-9 col-xl-9" style="margin-top: 100px">
                    <div class="section-title text-left">
                        <div class="section-title__02">Electrical Products</div>
                        <div class="section-title__01">Best Quality Parts</div>
                        <div class="section-title__03">We offer complete lines of Professional Manufacturer Lighting &
                            Electrical products at Wholesale Prices. We make it our job to provide the best price and
                            most gratifying shopping experience.
                        </div>
                    </div>

                    <div id="tt-product-listing" class="tt-product-listing row">
                        <div class="col-6 col-md-4 tt-col-item">
                            <div class="tt-product">
                                <div class="tt-product__img"><a href="."><img
                                                src="images/product/product-01.jpg" alt=""></a></div>
                                <div class="tt-product__description"><h2 class="tt-product__title"><a
                                                href=".">Woods WiOn 15 amps Receptacle and USB Charger</a></h2>
                                    <div class="tt-price">$41.99</div>
                                    <div class="tt-row-btn"><a href="#" class="tt-btn-addtocart"><i
                                                    class="tt-icon icon-808584"></i> Add to cart</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 tt-col-item">
                            <div class="tt-product">
                                <div class="tt-product__img"><a href="."><img
                                                src="images/product/product-04.jpg" alt=""></a></div>
                                <div class="tt-product__description"><h2 class="tt-product__title"><a
                                                href=".">Combination Toggle Switch</a></h2>
                                    <div class="tt-rating"><i class="icon-favorite"></i> <i class="icon-favorite"></i>
                                        <i class="icon-favorite"></i> <i class="icon-favorite"></i> <i
                                                class="icon-favorite"></i></div>
                                    <div class="tt-price">$15.99</div>
                                    <div class="tt-row-btn"><a href="#" class="tt-btn-addtocart"><i
                                                    class="tt-icon icon-808584"></i> Add to cart</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 tt-col-item">
                            <div class="tt-product">
                                <div class="tt-product__img"><a href="."><img
                                                src="images/product/product-06.jpg" alt=""></a></div>
                                <div class="tt-product__description"><h2 class="tt-product__title"><a
                                                href=".">Rotary Fan Speed Control</a></h2>
                                    <div class="tt-rating"><i class="icon-favorite"></i> <i class="icon-favorite"></i>
                                        <i class="icon-favorite"></i> <i class="icon-favorite"></i> <i
                                                class="icon-favorite"></i></div>
                                    <div class="tt-price">$23.99</div>
                                    <div class="tt-row-btn"><a href="#" class="tt-btn-addtocart"><i
                                                    class="tt-icon icon-808584"></i> Add to cart</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 tt-col-item">
                            <div class="tt-product">
                                <div class="tt-product__img"><a href="."><img
                                                src="images/product/product-07.jpg" alt=""></a></div>
                                <div class="tt-product__description"><h2 class="tt-product__title"><a
                                                href=".">Intermatic Outdoor Portable Timer</a></h2>
                                    <div class="tt-price"><span class="new-price">$30.99</span> <span class="old-price">$32.32</span>
                                    </div>
                                    <div class="tt-row-btn"><a href="#" class="tt-btn-addtocart"><i
                                                    class="tt-icon icon-808584"></i> Add to cart</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 tt-col-item">
                            <div class="tt-product">
                                <div class="tt-product__img"><a href="."><img
                                                src="images/product/product-08.jpg" alt=""></a></div>
                                <div class="tt-product__description"><h2 class="tt-product__title"><a
                                                href=".">Ace® 12/3 SPT-3 9ft Major Appliance Cord</a></h2>
                                    <div class="tt-price">$16.99</div>
                                    <div class="tt-row-btn"><a href="#" class="tt-btn-addtocart"><i
                                                    class="tt-icon icon-808584"></i> Add to cart</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 tt-col-item">
                            <div class="tt-product">
                                <div class="tt-product__img"><a href="."><img
                                                src="images/product/product-09.jpg" alt=""></a></div>
                                <div class="tt-product__description"><h2 class="tt-product__title"><a
                                                href=".">General Purpose Indoor Extension Cord in Various Sizes</a>
                                    </h2>
                                    <div class="tt-price">$34.99</div>
                                    <div class="tt-row-btn"><a href="#" class="tt-btn-addtocart"><i
                                                    class="tt-icon icon-808584"></i> Add to cart</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tt-pagination">
                        <ul>
                            <li class="active"><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">...</a></li>
                            <li><a href="#">8</a></li>
                        </ul>
                    </div>
            </div>
        </div>
    </div>
    </div>
</main>
<?php include("utilities/footer.php");?>
<a href="#" id="js-backtotop" class="tt-back-to-top"><i class="icon-lightning"></i></a>




<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/preloader.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="css/owlCustom/owl.carouselcustom.min.js"></script>
<script src="js/owl-Custom.js"></script>
<script async="" src="js/bundle.js"></script>
<script async="" src="js/js.js"></script>
</body>
</html>