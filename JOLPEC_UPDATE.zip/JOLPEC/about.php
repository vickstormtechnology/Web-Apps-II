<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>JOLPEC | ABOUT</title>
    <meta content="Jolpec Environmemtal Cleaning Services,Jolpec, Jolpec,cleaning, home cleaning , hospital cleaning , office cleaning,sweeping,dusting" name="keywords">
    <meta name="description" content="Jolpec Limited provides cleaning services to Commercial, Industrial, Residential, and Retail Properties in Lagos, Abuja, Porth Harcourt, and we continue to expand our services to various parts of the country">
    <meta name="author" content="Jolpec">
    <link rel="shortcut icon" href="images/favicon.png">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no,maximum-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/preloader.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owlCustom/owl.carousel-custom.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.css" rel="stylesheet"/>
    <link rel="stylesheet" href="css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&amp;family=Roboto:wght@400;700&amp;display=swap"
          rel="stylesheet">
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <style>
        .owl-carousel {
            position: relative;
        }
        .owlNavNew{
            font-size: 20px;
            font-weight: bold;
            cursor: pointer;
        }
        .owl-prev2 {
            float: left;
            left:0;
        }
        .owl-next2 {
            right:0;
            float: right
        }
    </style>
</head>
<body>
<div id="preloader">
    <div id="status"></div>
</div>
<?php require('utilities/nav-top.php');?>
<div class="owl-carousel-Custom navSlide">
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">A nice text here if need be</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg2.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">Another wonderful text</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="item">
        <div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg3.jpg')">
            <div class="container container-lg-fluid">
                <ul>
                    <li><a href="index.php">Another wonderful text</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<main id="tt-pageContent">


<div class="owl-carousel" id="aboutTop">

    <div class="section-indent item" >
        <div class="container container-lg-fluid" >
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more" >
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main"><img src="images/layout01-img03.jpg" alt=""></div>
                    <div class="tt-img-more left-bottom"><img src="images/layout01-img03-02.jpg" alt=""></div>
                </div>
                <div class="layout01__content" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper" >
                        <div class="section-title text-left" >
                            <div class="section-title__01">About Our Company</div>
                        </div>
                        <p >
                            Jolpec Int’l Ltd offers a Comprehensive and Competitive Engineering Services to different sectors of the Nigerian economy. It is an innovative company committed to delivering excellence in all areas of our business.
                            <br>
                            Jolpec has a Team of Experienced Managers with backgrounds in the Civil Engineering and Construction Industry. From the head office in Lagos, Nigeria, the company aims to offer Services where Quality, Efficiency, and Values are key fundamentals. It is the intention of the company to employ Experienced Workforce, and to implement a Training and Development Program to the benefit of our staff.
                        </p>
                        <p class="tt-list01 tt-list-top">
                            Our experienced and professional team includes Project Managers, Engineers, Supervisors, Health, Safety and Environment Officers, Surveyors, and Architects, backed by a Dedicated Management and Administrative Team. With a variety of project locations in different parts of the country, our employees have the flexibility to travel and develop their skills and knowledge on the variety of projects we undertake.
                        </p>
                    </div>
                </div>
            </div>
            <p class="underText" >
                We have the Knowledge, Skills and Expertise to Delivering Projects. The company is fully committed to delivering a modern and effective service to our customers, using the latest industry procedures, to ensure that all projects are delivered on time and within budget. Our pro-active approach and management systems ensure an effective and prompt interaction with Clients, Design and Construction Team members.
            </p><br>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>







    <div class="section-indent item" >
        <div class="container container-lg-fluid" >
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more" >
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main"><img src="images/layout01-img03.jpg" alt=""></div>
                    <div class="tt-img-more left-bottom"><img src="images/layout01-img03-02.jpg" alt=""></div>
                </div>
                <div class="layout01__content" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper" >
                        <div class="section-title text-left" >
                            <div class="section-title__01">About Our Company</div>
                        </div>
                        <p >
                            Established in 2007, and with over 12 years of experience in Engineering Services, Design and Construction. Jolpec Int’l Ltd has grown into a strong Construction and Development Company.
<br>
                            Jolpec was established to fulfill its’ key function, ranging from Project Conception, Design, Construction, Management of the Professional Team to the final hand over of the development. As Building Contractors and Developers, Jolpec Int’l is well Competent to undertake the most Technical Constructions. We have the capability to direct and manage the works from Design to Commissioning.                        </p>
                        <p class="tt-list01 tt-list-top">
                            We are experienced, having a proven track record in a large variety of Building Constructions, including; Residential, Commercial and Industrial Engineering Construction Projects in different parts of the country.
                        </p>
                        <p>Jolpec Int’l has three main divisions, Engineering Services, Engineering Designs, and Construction.</p>
                        <p> These three divisions are the core business allowing us to undertake a broad range of Engineering Projects. Our company has extensive experience in Civil Construction, employing Professional Project Managers, Engineers, Surveyors, and Architects.</p>
                    </div>
                </div>
            </div>
            <p class="underText" >
                At Jolpec, we believe that the Success of any Project commences with Understanding Individual Strengths and the Formation of a Compatible, Committed and Well-resourced Construction Team that understands the requirements and anticipated outcomes. Consideration is also given to the construction team’s ability to function collaboratively within the Project Control Group.
            </p><br>
                <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
                <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>




    <div class="section-indent item animated">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Our Vision
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            We aspire to be a leading Engineering Services, Design and Construction Company in Nigeria that could achieve growth and stability by creating a pleasant work environment and overall satisfaction through teamwork.                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Our Mission
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: black;font-family: arial;font-size: 0.9rem;">
                            To Consistently Deliver Quality Projects on Schedule and Budget to its’ customers in a Safe, Qualitative and Cost-effective Manner across Nigeria, using the best available Environmental Friendly Technology under the control of experienced and highly motivated work force to meet with set global standards.                        </p>
                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Our Core Values
                        </h3>
                        <ul class="tt-list01 tt-list-top">
                            <li>Growth</li>
                            <li>Excellence</li>
                            <li>Innovation</li>
                            <li>Integrity</li>
                            <li>Team work</li>
                            <li>Empowerment</li>
                            <li>Professionalism</li>
                            <li>Accountability</li>
                        </ul>
                    </div>
                </div>
            </div>
            <br>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>



    <div class="section-indent item animated">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Valuing Our People
                        </h3>
                        <p class="w2-text formatted_p" style="color: ;font-family: arial;font-size: 0.9rem;">
                            We believe that our most important assets are the people we employ.  Our people are crucial in the delivering of our services and solutions to our clients. In order to ensure that everyone is equipped with the Right Skills, Knowledge and Attitude, a Comprehensive Training Program is put in place to constantly upgrade our people in Technical and Management Skills.                        </p>
                        <p class="w2-text formatted_p" style="color: black;font-family: arial;font-size: 0.9rem;">
                            We believe firmly in providing the right training, accredited certification and practical knowledge for our people, for them to execute their responsibilities confidently
    <br>
                            Our experienced team members mentor our new employees. This entails developing and guiding them to ensure that our clients’ needs are met, while delivering projects that meet approved Quality, Safety and Environmental Standards.
                        </p>


                        <h4 class="lead sub_title" style="color:#f47629;font-size:1.2rem;">
                            Training and Development
                        </h4>
                        <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
                        <p>We always encourage Further Training and Development of our employees who wish to increase their Skills, Knowledge and Expertise, hence allowing progression through the company. We offer our employees the chance to learn from some of the strongest and most experienced teams and professionals in the industry, and to apply their skills in their chosen field. </p>
                        </p>
                    </div>
                </div>

            </div>

            <p style="margin-top: -5px;">We offer our apprentices the opportunity to take on the challenge of our industry with the support and knowledge of our long-term employees to teach and guide them. We support them in continuing their development and gaining qualifications in the construction industry. </p><br>

                <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
                <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
            <br>
        </div>
    </div>



    <div class="section-indent item animated ">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h4 class="lead sub_title" style="color:#f47629;font-size:1.2rem;">
                            Training
                        </h4>
                        <p>
                            Training of staff must be highly prioritized in order to create and maintain a satisfied and motivated workforce and customers while providing controlled expansion.
                            <br>
                            Training and Development will ensure that all employees are given the necessary Opportunity and Assistance to Develop Knowledge, Skills and Attitude required to successfully carry out their responsibilities.
                            <br>
                            The company will endeavor to provide training to satisfy its requirements as identified by managers and personnel appraisal, to fulfill the needs of the individual.

                        </p>

                        <p><b>Training should be prioritized as follows:</b>

                        <ul class="tt-list01 tt-list-top">
                            <li>Maintenance Training </li>
                            <li>Strategic Training </li>
                            <li>Personal Development </li>
                        </ul>
                        </p>

                        <p><b>The general aims will be:</b>
                        <ul class="tt-list01 tt-list-top">
                            <li>Providing Training, which includes formal induction on regular basis to update understanding of the company’s Objectives, Policies and Procedures</li>
                            <li>Encouragement of Job Satisfaction and Maintain Efficiency and Development</li>
                        </ul>

                    </div>
                </div>
            </div>
            <p class="underText" style="color: black;font-family: arial;font-size: 0.9rem;">
            <ul class="tt-list01 tt-list-top">
                <li>All employees will receive training in Health, Safety and the Environment at varying levels in order to meet the needs of the individual and ensure compliance with current Health and Safety legislation and codes of practice.</li>
                <li>The directors will identify, at least annually, the training that will be required to help the company meet its target. </li>
                <li>Career related further education should be encouraged. </li>
                <li>Regular Site Manager training, and Promotion of Tool-Box Talks</li>
                <li>Implementation of Staff and Employee Appraisal System</li>
            </ul>
            </p>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>




    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;">
                            Education
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: ;font-family: arial;">
                            Jolpec Int’l encourages and supports her employees to further their education in areas such as Civil Engineering, Surveying and Estimating, Architecture, Mechanical, Electrical, ICT
                            <br>
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;">
                            Environmental Excellence
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: ;font-family: arial;">
                            We understand that caring for our environment is vital and we are committed to the principles of environmental excellence and sustainable development. Our group is taking measures to minimize impacts on global warming through greenhouse gas emission controls and monitoring.
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Environmental Management Policy
                        </h3>
                        <p>
                            Jolpec believes that a protected environment holds a future for all, and is thus committed to maintaining a clean environment and support the environmental program. This creates the ability to operate in a disciplined and sustainable manner over the long term.
                        </p>
                        <p>
                            Our company policy is that the fulfillment of its legal and statutory responsibilities represents the minimum level of achievement in respect to environmental control. Management and Employees of Jolpec therefore, commit themselves to actively participate in the environmental control plan.
                        </p>
                    </div>
                </div>
            </div>
            <p class="underText" style="color: ;font-family: arial;">
                The Management and Workforce at Jolpec is committed to the Care of the Environment and the Prevention of Pollution.
                The organization ensures that all its activities are carried out in conformance with relevant legislation, approved codes of practice and associated statutory requirements. Jolpec seeks to minimize waste arising from its operations, promotes recycling, reduce energy consumption and emissions.<br><br>
            </p>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>




    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Our Commitment to Safety
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;font-family: arial;font-size:;">
                            We take Safety seriously, and are constantly improving our Policies and Procedures to ensure a Safe Work Environment. We employ Safety Officers to ensure that all policies and procedures are adhered to, in order to meet our Zero-Harm Target. Safety is our first priority at every stage throughout our projects, from the Design and Planning Stages through to Completion. At every level, our workforce makes zero harm safety our main objective. Our commitment is to provide a safe work environment for our employees and for everyone who visits our project sites. Our senior management team has a commitment to ensure that our employees, the public and the environment are safe at all times. Our ultimate goal is to reach zero harm in our workplace.
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Safety Strategies
                        </h3>
                        <ul class="tt-list01 tt-list-top">
                            <li>Ongoing Supervision and Training </li>
                            <li>Incident Reporting and Investigation</li>
                            <li>Daily Site Safety Toolbox Meetings</li>
                            <li>Newsletter Updates detailing Health and Safety Issues </li>
                        </ul>
                    </div>
                </div>
            </div>
            <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                Health and Safety Policy
            </h3>
            <p class="underText" style="color: ;font-family: arial;font-size: ;">
                Jolpec developed a Safety Management System that is aimed to meet the specific needs of our company. This is continually developed to ensure the Safety, Health and Welfare of our staff. We recognize and appreciate that all employees play a part in the safety management of the company, and we actively promote a culture to ensure their participation.
                <br/>
                <br/>
                Health and Safety are recognized, implemented and maintained from Legal, Humanitarian, and Economic perspectives. We believe that a superior safety approach is indicative of assertiveness and responsiveness to employee needs and policy procedures. As a result, higher morale and loyalty are reached amongst employees, promoting enhanced productivity, which leads to profitability.
                <br>
                <br>
                It is the policy of Jolpec to comply with all legislations relevant to business and operations carried out by its management and our employees. We are committed to identifying new legislations and best practices, and also adhering to changing standards.
                It is our aim to achieve a working environment, which is free of work related accidents and ill health.  To this end, we will pursue continuing improvements at all time.
                Therefore, we strive to safeguard our Employees and the General Public, so far as reasonably practical from Injury, Annoyance, or Risk during all company operations and activities.
                <br>
                <br>
            </p>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>

        </div>
    </div>






    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-2" style="color:#f47629;font-size:1.2rem;">
                            Quality
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: ;font-family: arial;font-size: ;">
                            To provide excellent services and installations for all our clients, Jolpec Quality Management System has continually been improved, and updated to ensure that the best quality of workmanship and management systems are utilized. The system is utilized from project commencement to project completion stage, and covers both the contract administration procedures, and installation requirements, to ensure delivery of top quality projects to our clients.
                            <br>
                            <br>
                            The Administrative Quality procedures have been developed to ensure timely, clear and concise communication with all parties. The Construction Quality procedures are equally developed to ensure the very highest standard within the industry.
                            <br>Jolpec has also been involved in a number of projects incorporating Energy and Efficient Design
                        </p>

                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Active Community Involvement
                        </h3>
                        <p class="w2-text formatted_p" style="display: inline;display: inline;color: ;font-family: arial;font-size: ;">
                            Our company has strong community values. We acknowledged that as a good corporate citizen, the company should be actively involved in the community development. We provide Free Medical Outreach, and also support Work Experience (on-the-job training) for School Leavers, and Engineering Students from different Higher Institutions in the regions of our operation, who want a career in Civil Construction.
                        </p>
                    </div>
                </div>
            </div>
            <br><br>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>






    <div class="section-indent item animated owl-animated-in">
        <div class="container container-lg-fluid">
            <div class="layout01 layout01__revers layout01__small-layout layout01__img-more">
                <div class="layout01__bg-marker"><img src="images/bg_marker02.png" alt=""></div>
                <div class="layout01__img">
                    <div class="tt-img-main">
                        <img src="images/layout01-img03.jpg" alt="">
                    </div>
                    <div class="tt-img-more left-bottom">
                        <img src="images/layout01-img03-02.jpg" alt="">
                    </div>
                </div>
                <div class="layout01__content about2" style="margin-top: -100px;">
                    <div class="layout01__content-wrapper">
                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Our Team
                        </h3>
                        <p class="underText" style="color: ;font-family: arial;font-size: ">
                            Jolpec staff includes Architects, Civil Engineers, Structural, Mechanical and Electrical Engineers, and Professional Land, and Quantity Surveyors with extensive experience in the planning and development of a vast array of infrastructure projects, including Public Drinking Water, Wastewater, Sanitary Sewer, Storm Water, Site Development, and Transportation (Streets, Roads, Bridges).
                            Our staff is comprised of Certified Professional Engineers (PE). Our professional staff is supported by highly Trained, Technical and Administrative Personnel, experienced in Design, Project Management, Project Financing, Construction Engineering, Construction Management, and Construction Observation. Our team of experienced staff gives us the capacity to provide complete, and comprehensive professional services to our clients’ projects.
                        </p>
                        <h3 class="mytitles mt-4" style="color:#f47629;font-size:1.2rem;">
                            Our Experience
                        </h3>
                        <p style="color: ;font-family: arial;font-size: ;">
                            Our firm’s success can be attributed to our outstanding reputation, the quality of our service, and our attentiveness to clients. Our goal as a consulting firm is to develop long-term relationships with our clients, working side-by-side with them to develop appropriate strategies for projects that will meet their needs, now and also in the future.
                            Contact Jolpec Engineering for your Public Works, Civil, Structural, Bridge, Transportation, Mechanical and Electrical Engineering, and professional Land Surveying needs.

                        </p>
                    </div>
                </div>
            </div>
            <div class='customPrevBtn owlNavNew owl-prev2'><i class='fa fa-arrow-circle-left'></i> Back</div>
            <div class='customNextBtn owlNavNew owl-next2'>Read more <i class='fa fa-arrow-circle-right'></i></div>
        </div>
    </div>








</div>

    <!--<div align="center" class="col-lg-6 col-md-6 col-sm-6 arrow-box">
        <div id="prev-slide" class="prev" style='font-size: 30px;font-weight: bold;float: left'><i class='fa fa-chevron-left'></i>Prev</div>
        <div id="next-slide" class="next" style='font-size: 30px;font-weight: bold;float: right'>Next<i class='fa fa-chevron-right'></i></div>
    </div>-->

    <div class="section-indent">
        <div class="container container-md-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__02">AREAS OF SERVICE</div>
            </div>
            <div id="filter-layout" class="row justify-content-center gallery-innerlayout-wrapper js-wrapper-gallery">
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Electrical-Engineering.png" style="width: 100px;" alt="">
                        <p> Electrical Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Structural-Engineering.png" style="width: 100px;" alt="">
                        <p> Civil/Structural Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Manufacturing-Process-Design-Icon5.png" style="width: 100px;" alt="">
                        <p> Engineering Designs </p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Construction-Administration.png" style="width: 100px;" alt="">
                        <p> Engineering Consultancy</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Software-HECI.png" style="width: 100px;" alt="">
                        <p> Architectural Services</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/plumber.png" style="width: 100px;" alt="">
                        <p> Plumbing Services</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Structural-Engineering.png" style="width: 100px;" alt="">
                        <p> Structural Steel Fabrication</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys" >
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/roof.png" style="width: 100px;" alt="">
                        <p> Cladding (Aluco Bond)</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/curtin.png" style="width: 100px;" alt="">
                        <p> Curtain Walling</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/glassWall.png" style="width: 100px;" alt="">
                        <p> Glass Wall</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" ddsrc="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/doors.png" style="width: 100px;" alt="">
                        <p> Aluminum Doors</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/window.png" style="width: 100px;" alt="">
                        <p> Aluminum Windows</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Mechanical-Engineering2.png" style="width: 100px;" alt="">
                        <p> Mechanical Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/solar.png" style="width: 100px;" alt="">
                        <p> Solar Panels Installation and Maintenance</p>
                    </a>

                </div>

                <div style="display:none !important;" class="col-12 text-center tt-top-more">
                    <a href="#" class="tt-link tt-link__lg">
                        View all services
                        <span class="icon-arrowhead-pointing-to-the-right-1"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>



    <div class="section-indent">
        <div class="container container-lg-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__02">Reasons You Should Call Us</div>
                <div class="section-title__03">Electrician is your single source for a complete range of high-quality
                    electrical services, including design/build, engineering and maintenance.
                </div>
                <div class="section-title__01">Our Advantages</div>
            </div>
            <div class="row tt-services-promo__list justify-content-center">
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value tt-value__indent">1</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-hours"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">24/7 Emergency Services</div>
                                <p>24/7 emergency electrician you can trust.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value">2</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-tool2"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">Free Estimates</div>
                                <p>Yes, we offer free estimates for electrical additions or replacements.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value">3</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-price-tag"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">Low Price Guarantee</div>
                                <p>We strive to offer the lowest price on the market.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</main>
<?php include("utilities/footer.php");?>
<a href="#" id="js-backtotop" class="tt-back-to-top"><i class="fa fa-arrow-up"></i></a>



<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/preloader.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="css/owlCustom/owl.carouselcustom.min.js"></script>
<script src="js/owl-Custom.js"></script>
<script async="" src="js/bundle.js"></script>
<script async="" src="js/js.js"></script>
</body>
</html>