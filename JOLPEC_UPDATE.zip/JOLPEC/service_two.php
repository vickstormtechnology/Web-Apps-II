<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>JOLPEC | SERVICE</title>
    <meta content="Jolpec Environmemtal Cleaning Services,Jolpec, Jolpec,cleaning, home cleaning , hospital cleaning , office cleaning,sweeping,dusting" name="keywords">
    <meta name="description" content="Jolpec Limited provides cleaning services to Commercial, Industrial, Residential, and Retail Properties in Lagos, Abuja, Porth Harcourt, and we continue to expand our services to various parts of the country">
    <meta name="author" content="Jolpec">
    <link rel="shortcut icon" href="images/favicon.png">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no,maximum-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/preloader.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.css" rel="stylesheet"/>
    <link rel="stylesheet" href="css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&amp;family=Roboto:wght@400;700&amp;display=swap"
          rel="stylesheet">
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <style>
        .owl-carousel {
            position: relative;
        }
        .owlNavNew{
            font-size: 20px;
            font-weight: bold;
            cursor: pointer;
        }
        .owl-prev2 {
            float: left;
            left:0;
        }
        .owl-next2 {
            right:0;
            float: right
        }

        @media screen and (max-width: 700px) {
            /*.owl-prev {
                margin-left: 30px;
                left:0;
            }
            .owl-next {
                right:0;
                margin-right: 30px;
            }
            .about2{
                margin-top: 5px !important;
            }*/
        }

    </style>
</head>
<body>
<div id="preloader">
    <div id="status"></div>
</div>
<?php require('utilities/nav-top.php');?>
<div class="tt-breadcrumb" style="background-image: url('images/breadcrumb_bg.jpg')">
    <div class="container container-lg-fluid">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li>Services</li>
        </ul>
    </div>
</div>
<main id="tt-pageContent">
    <div class="section-indent">
        <div class="container container-md-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__02">What We Offer</div>
            </div>
            <div id="filter-nav" align="center">
                Click on a photo or the read more link to learn more about our service
            </div>
            <div id="filter-layout" class="row justify-content-center gallery-innerlayout-wrapper js-wrapper-gallery">
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Electrical-Engineering.png" style="width: 100px;" alt="">
                        <p> Electrical Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Structural-Engineering.png" style="width: 100px;" alt="">
                        <p> Civil/Structural Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Manufacturing-Process-Design-Icon5.png" style="width: 100px;" alt="">
                        <p> Engineering Designs </p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Construction-Administration.png" style="width: 100px;" alt="">
                        <p> Engineering Consultancy</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Software-HECI.png" style="width: 100px;" alt="">
                        <p> Architectural Services</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/plumber.png" style="width: 100px;" alt="">
                        <p> Plumbing Services</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Structural-Engineering.png" style="width: 100px;" alt="">
                        <p> Structural Steel Fabrication</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys" >
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/roof.png" style="width: 100px;" alt="">
                        <p> Cladding (Aluco Bond)</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/curtin.png" style="width: 100px;" alt="">
                        <p> Curtain Walling</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/glassWall.png" style="width: 100px;" alt="">
                        <p> Glass Wall</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" ddsrc="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/doors.png" style="width: 100px;" alt="">
                        <p> Aluminum Doors</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/window.png" style="width: 100px;" alt="">
                        <p> Aluminum Windows</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/Mechanical-Engineering2.png" style="width: 100px;" alt="">
                        <p> Mechanical Engineering</p>
                    </a>

                </div>
                <div class="col-4 col-md-3 col-custom-item5 residences show all" align="center">
                    <a href="services.php" class="tt-gallerys">
                        <div class="gallery__icon"></div>
                        <img class="lazyload" src="data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=" data-src="images/services/solar.png" style="width: 100px;" alt="">
                        <p> Solar Panels Installation and Maintenance</p>
                    </a>

                </div>

                <div style="display:none !important;" class="col-12 text-center tt-top-more">
                    <a href="#" class="tt-link tt-link__lg">
                        View all services
                        <span class="icon-arrowhead-pointing-to-the-right-1"></span>
                    </a>
                </div>
            </div>
        </div>
    </div>



    <div class="section-indent">
        <div class="container container-lg-fluid">
            <div class="section-title max-width-01">
                <div class="section-title__01">Our Advantages</div>
                <div class="section-title__02">Reasons You Should Call Us</div>
                <div class="section-title__03">Electrician is your single source for a complete range of high-quality
                    electrical services, including design/build, engineering and maintenance.
                </div>
            </div>
            <div class="row tt-services-promo__list justify-content-center">
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value tt-value__indent">1</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-hours"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">24/7 Emergency Services</div>
                                <p>24/7 emergency electrician you can trust.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value">2</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-tool2"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">Free Estimates</div>
                                <p>Yes, we offer free estimates for electrical additions or replacements.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 tt-item">
                    <div class="tt-services-promo">
                        <div class="tt-value">3</div>
                        <div class="tt-wrapper">
                            <div class="tt-col-icon icon-price-tag"></div>
                            <div class="tt-col-layout">
                                <div class="tt-title">Low Price Guarantee</div>
                                <p>We strive to offer the lowest price on the market.</p></div>
                        </div>
                        <div class="tt-bg-marker"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</main>
<?php include("utilities/footer.php");?>
<a href="#" id="js-backtotop" class="tt-back-to-top"><i class="fa fa-arrow-up"></i></a>



<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/preloader.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/owl-Custom.js"></script>
<script async="" src="js/bundle.js"></script>
<script async="" src="js/js.js"></script>
</body>
</html>