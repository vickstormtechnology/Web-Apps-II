<style>
    @media screen and (max-width: 700px) {
        .caret_icon{
            display: none;
        }
        .caret_icon2{
            display: none;
        }
    }
</style>

<nav class="panel-menu" id="mobile-menu">
    <ul></ul>
    <div class="mm-navbtn-names">
        <div class="mm-closebtn">Close</div>
        <div class="mm-backbtn">Back</div>
    </div>
</nav>
<header id="tt-header">
    <div class="holder-top-mobile d-block d-md-none" >
        <div class="h-topbox__content" style="display: block !important;"><!---Mobile social icon auto drop down-->
            <div class="tt-item">
                <div class="tt-item__icon"><span class="icon-482948"></span></div>
                <div class="tt-item__text"><a href="mailto:info@ejecs.com.ng">info@ejecs.com.ng</a></div>
            </div>
            <div class="tt-item">
                <div class="tt-item__icon"><span class="icon-telephone"></span></div>
                <div class="tt-item__text">
                    <address>
                        <a href="tel:+234 (0) 816 842 3411">
                            +234 (0) 816 842 3411
                        </a><span> OR </span>
                        <a href="tel:+234 (0) 806 693 4496">
                            +234 (0) 806 693 4496
                        </a>
                    </address>
                </div>
            </div>
            <div class="tt-item">
                <div class="tt-obj tt-obj-cart js-dropdown-cart">
                    <a href="." class="tt-obj_social">
                            <span class="radius_social" style="background: green;">
                                <i class="top-icon fa fa-phone"></i>
                            </span>
                    </a>
                    <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: steelblue;">
                                <i class="top-icon fa fa-envelope"></i>
                            </span>
                    </a>
                    <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: #3b5998 !important;">
                            <i class="top-icon fa fa-facebook"></i>
                            </span>
                    </a>
                    <a href="" class="tt-obj_social">
                             <span class="radius_social" style="background: -webkit-linear-gradient(#bf3801, #bf3801, #f99aa1) !important;">
                            <i class="top-icon fa fa-instagram"></i>
                             </span>
                    </a>
                    <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: red !important;">
                            <i class="top-icon fa fa-youtube-play"></i>
                            </span>
                    </a>
                    <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: -webkit-linear-gradient(#bf3801, #942b01, #f9a498) !important;">
                            <i class="top-icon fa fa-twitter"></i>
                            </span>
                    </a>
                    <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: #0e76a8 !important;">
                            <i class="top-icon fa fa-linkedin-square"></i>
                            </span>
                    </a>
                    <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: #20c997 !important;">
                            <i class="top-icon fa fa-whatsapp"></i>
                            </span>
                    </a>
                </div>
            </div>
        </div>
        <a href="#" class="h-topbox__btn" id="js-toggle-h-holder"><i class="tt-arrow down"></i></a>
    </div>


    <!-- /holder-top (mobile) --><!-- holder-top (desktop) -->
    <div class="holder-top-desktop d-none d-md-block">
        <div class="container container-lg-fluid">
            <div class="row no-gutters">
                <div class="col-auto">
                    <div class="h-info01">
                        <div class="tt-item">
                            <address>
                                Call us today for a quote
                                <span class="icon-telephone"></span>
                                <a href="tel:+234 (0) 816 842 3411">
                                    +234 (0) 816 842 3411
                                </a>
                                <span class="spacer"></span>
                                <a href="tel:+234 (0) 806 693 4496">
                                    +234 (0) 806 693 4496
                                </a>
                            </address>
                        </div>
                    </div>
                </div>
                <div class="col-auto ml-auto">
                    <div class="tt-obj tt-obj-cart js-dropdown-cart">
                        <a href="." class="tt-obj_social">
                            <span class="radius_social" style="background: green;">
                                <i class="top-icon fa fa-phone"></i>
                            </span>
                        </a>
                        <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: steelblue;">
                                <i class="top-icon fa fa-envelope"></i>
                            </span>
                        </a>
                        <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: #3b5998 !important;">
                            <i class="top-icon fa fa-facebook"></i>
                            </span>
                        </a>
                        <a href="" class="tt-obj_social">
                             <span class="radius_social" style="background: -webkit-linear-gradient(#bf3801, #bf3801, #f99aa1) !important;">
                            <i class="top-icon fa fa-instagram"></i>
                             </span>
                        </a>
                        <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: red !important;">
                            <i class="top-icon fa fa-youtube-play"></i>
                            </span>
                        </a>
                        <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: -webkit-linear-gradient(#bf3801, #942b01, #f9a498) !important;">
                            <i class="top-icon fa fa-twitter"></i>
                            </span>
                        </a>
                        <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: #0e76a8 !important;">
                            <i class="top-icon fa fa-linkedin-square"></i>
                            </span>
                        </a>
                        <a href="" class="tt-obj_social">
                            <span class="radius_social" style="background: #20c997 !important;">
                            <i class="top-icon fa fa-whatsapp"></i>
                            </span>
                        </a>
                        <div class="tt-obj tt-obj-cart js-dropdown-cart">
                            <a href="checkout.php" class="tt-obj__btn" >
                                <i class="icon-808584"></i>
                                <div class="tt-obj__badge">2</div>
                            </a>
<!--                            <div class="tt-obj__dropdown" >-->
<!--                                <ul>-->
<!--                                    <li><a href="#"><i class="icon-808584"></i> Good service listed <span class="product-unit">$20</span></a></li>-->
<!--                                    <li><a href="#"><i class="icon-808584"></i> Good service listed <span class="product-unit">$20</span></a></li>-->
<!--                                </ul>-->
<!--                            </div>-->

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /holder-top (desktop) --><!-- holder- -->
    <div id="js-init-sticky" >
        <div class="tt-holder-wrapper custom">
            <div class="container container-lg-fluid" >
                <div class="tt-holder" style="background: transparent !important;">
                    <div class="tt-col-logo"><!-- logo -->
                        <a href="index.php" class="tt-logo tt-logo-alignment">
                            <span class="tt-ico">
                                <img style="width: 80px;" src="images/logo.png" alt="">
                            </span>

                        </a><!-- /logo -->
                    </div>

                    <div class="tt-col-objects tt-col-wide text-center"><!-- desktop-nav -->

                        <nav id="tt-nav">
                            <ul>
                                <li><a href="index.php">
                                        <div class="electric-btn"><span class="text">Home</span>

                                        </div>
                                    </a>
                                </li>
                                <li><a href="services.php">
                                        <div class="electric-btn"><span class="text">Services <i class="fa fa-angle-down caret_icon2"> </i></span>
                                            <div class="mask"><span>Services <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Services <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Services <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Services <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Services <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Services <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                        </div>
                                    </a>
                                    <ul style="width: 300px;">
                                        <li><a href="service_two.php">Services Two</a></li>

                                        <li><a href="services-item.php">After Work/Weekend Cleaning <i class="fa fa-caret-right caret_icon"></i></a>
                                            <ul style="width: 350px;">
                                                <li><a href="services-item.php">Dust all accessible surfaces</a></li>
                                                <li><a href="services-item.php">Bed room, living room and common room area</a></li>
                                                <li><a href="services-item.php">Clean all floor surface</a>
                                                <li><a href="services-item.php">Wash and sanitize the toilet</a>
                                                <li><a href="services-item.php">Bathroom Cleaning</a>
                                                <li><a href="services-item.php">Kitchen Cleaning</a>
                                                <li><a href="services-item.php">Wipe down exterior of stove, oven and Fridge</a>
                                                <li><a href="services-item.php">Laundry wash</a>
                                                <li><a href="services-item.php">Take out Garbage</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="services-item.php">Cleaning Services <i class="fa fa-caret-right caret_icon"></i></a>
                                            <ul style="width: 350px;">
                                                <li><a href="services-item.php">Commercial Cleaning Services</a></li>
                                                <li><a href="services-item.php">Domestic Cleaning Services</a></li>
                                                <li><a href="services-item.php">End of Tenancy Cleaning</a></li>
                                                <li><a href="services-item.php">Industrial Cleaning Services</a></li>
                                                <li><a href="services-item.php">Marble Restoration</a></li>
                                                <li><a href="services-item.php">Post Construction and  Renovation Cleaning</a></li>
                                                <li><a href="services-item.php">Upholstery  and Leather Cleaning</a></li>
                                            </ul>
                                        </li>

                                        <li><a href="services-item.php">Estate Cleaning Services</a></li>

                                        <li><a href="services-item.php">Facility Management <i class="fa fa-caret-right caret_icon"></i></a>
                                            <ul style="width: 350px;">
                                                <li><a href="services-item.php">What is Facilities Management?</a></li>
                                                <li><a href="services-item.php">Cleaning</a></li>
                                                <li><a href="services-item.php">Fumigation and Pest Control</a></li>
                                                <li><a href="services-item.php">Environment, Health, and Safety(EHS)</a></li>
                                                <li><a href="services-item.php">Waste Management</a></li>
                                                <li><a href="services-item.php">Fire &amp; Safety Services</a></li>
                                                <li><a href="services-item.php">Swimming Pool Cleaning and Maintenance</a></li>
                                                <li><a href="services-item.php">Septic Tank Evacuation and Cleaning</a></li>
                                                <li><a href="services-item.php">Drainage Cleaning & Repair</a></li>
                                                <li><a href="services-item.php"></a></li>
                                                <li><a href="services-item.php"></a></li>

                                            </ul>
                                        </li>

                                        <li><a href="services-item.php">Gardening & Landscaping</a></li>

                                        <li><a href="services-item.php">HSE <i class="fa fa-caret-right caret_icon"></i></a>
                                            <ul style="width: 350px;">
                                                <li><a href="services-item.php">Fire Safety</a></li>
                                                <li><a href="services-item.php">Health and Safety</a></li>
                                                <li><a href="services-item.php">EIA</a></li>
                                                <li><a href="services-item.php">PPE Sales</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="services-item.php">Janitorial Services <i class="fa fa-caret-right caret_icon"></i></a>
                                            <ul style="width: 350px;">
                                                <li><a href="services-item.php">Office Cleaning</a></li>
                                                <li><a href="services-item.php">Rest Room Sanitation</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>





                                <li><a href="contact.php">
                                        <div class="electric-btn"><span class="text">Contacts Us</span>
                                            <div class="mask"><span>Contacts Us</span></div>
                                            <div class="mask"><span>Contacts Us</span></div>
                                            <div class="mask"><span>Contacts Us</span></div>
                                            <div class="mask"><span>Contacts Us</span></div>
                                            <div class="mask"><span>Contacts Us</span></div>
                                            <div class="mask"><span>Contacts Us</span></div>
                                        </div>
                                    </a>
                                </li>


                                <li ><a href="product.php">
                                        <div class="electric-btn"><span class="text">Product <i class="fa fa-angle-down caret_icon2"> </i></span>
                                            <div class="mask"><span>Product <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Product <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Product <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Product <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Product <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Product <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                        </div>
                                    </a>
                                    <ul style="width: 300px;">
                                        <li><a href="product-item.php">PPE Sales</a></li>
                                        <li><a href="product-item.php">Fire Fighting Equipments Sales</a></li>
                                    </ul>
                                </li>
                                <li><a class="about" href="about.php">
                                        <div class="electric-btn"><span class="text">About Us <i class="fa fa-angle-down caret_icon2"> </i></span>
                                            <div class="mask"><span>About Us <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>About Us <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>About Us <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>About Us <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>About Us <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>About Us <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                        </div>
                                    </a>
                                    <ul>
                                        <li><a class="our-company" href="#">Our Company</a></li>
                                        <li><a class="vision" href="#">Vision & Mission</a></li>
                                        <li><a class="commitment" href="#">Commitments</a></li>
                                        <li><a class="why-choose-us" href="#">Why Choose Ejecs</a></li>
                                    </ul>
                                </li>

                                <li><a href="quote.php">
                                        <div class="electric-btn"><span class="text">Request a Quote</span>
                                            <div class="mask"><span>Request a Quote</span></div>
                                            <div class="mask"><span>Request a Quote</span></div>
                                            <div class="mask"><span>Request a Quote</span></div>
                                            <div class="mask"><span>Request a Quote</span></div>
                                            <div class="mask"><span>Request a Quote</span></div>
                                            <div class="mask"><span>Request a Quote</span></div>
                                        </div>
                                    </a>
                                </li>

                                <li><a href="about.php">
                                        <div class="electric-btn"><span class="text">Update <i class="fa fa-angle-down caret_icon2"> </i></span>
                                            <div class="mask"><span>Update <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Update <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Update <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Update <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Update <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                            <div class="mask"><span>Update <i class="fa fa-angle-down caret_icon2"> </i></span></div>
                                        </div>
                                    </a>
                                    <ul style="width: 300px;">
                                        <li><a href="about.php">Blog</a></li>
                                        <li><a href="about.php">Cleaning Tips</a></li>
                                        <li><a href="about.php">EJECS Recent Activities</a></li>
                                        <li><a href="about.php">Health Tips</a></li>
                                        <li><a href="about.php">Job Vacancy</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#" class="tt-obj_social" data-toggle="modal" data-target="#search-modal">
                                        <i class="tt-btn-icon icon-search"></i>
                                    </a>
                                </li>

                            </ul>
                        </nav><!-- /desktop-nav --></div>
                    <div class="tt-col-objects">
                        <div class="tt-col__item d-block d-lg-none">
                            <div class="tt-obj tt-obj-cart js-dropdown-cart">
                                <a href="#" class="tt-obj__btn"><i
                                            class="icon-808584"></i>
                                    <div class="tt-obj__badge">2</div>
                                </a>
                                <div class="tt-obj__dropdown"></div>
                            </div>
                        </div>
                        <div class="tt-col__item d-block d-lg-none">
                            <a href="#" id="tt-menu-toggle" class="icon-545705"></a>
                        </div>
                        <div class="tt-col__item d-none d-lg-block">
                            <a href="#" class="tt-btn btn__color01" data-toggle="modal" data-target="#modalMakeAppointment">
                                <span class="icon-lightning"></span>
                                Request Quote
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>